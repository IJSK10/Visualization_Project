"use client"
import { useState, useEffect } from "react";
import Histogram from '../components/histogram';
import HorizontalBarChart from '../components/horizontalBarChart'
import Gender from '../components/gender';
import PCPPlot from '../components/PCPPlot';
import LinePlot from '../components/linePlot';
import ScatterPlot from '../components/scatterPlot';
import RadarPlot from '../components/radarPlot';

export default function Home() {
  // Filter states
  const [distanceFromHome, setDistanceFromHome] = useState([]);
  const [parentalEducationLevel, setParentalEducationLevel] = useState([]);
  const [teacherQuality, setTeacherQuality] = useState([]);
  const [familyIncome, setFamilyIncome] = useState([]);
  const [motivationLevel, setMotivationLevel] = useState([]);
  const [accessToResources, setAccessToResources] = useState([]);
  const [parentalInvolvement, setParentalInvolvement] = useState([]);
  const [learningDisabilities, setLearningDisabilities] = useState([]);
  const [peerInfluence, setPeerInfluence] = useState([]);
  const [extracurricularActivities, setExtracurricularActivities] = useState([]);
  const [selectedBins, setSelectedBins] = useState([]);
  const [gender, setGender] = useState([]);
  const [selectedIds, setSelectedIds] = useState([]); // For brushing/selection

  // BarchartVariables array for bar chart (add new features here)
  const BarchartVariables = [
    'Parental_Involvement',
    'Access_to_Resources',
    'Motivation_Level',
    'Family_Income',
    'Teacher_Quality',
    'Parental_Education_Level',
    'Distance_from_Home',
    'Learning_Disabilities',
    'Peer_Influence',
    'Extracurricular_Activities'
  ];

  // Numeric features for scatter/radar
  const numericFeatures = [
    'Hours_Studied', 
    'Attendance', 
    'Sleep_Hours', 
    'Previous_Scores', 
    'Tutoring_Sessions',
    'Physical_Activity', 
    'Exam_Score'
  ];

  // PCP order handler
  const [order, setOrder] = useState([
    'Hours_Studied', 'Attendance', 'Parental_Involvement', 'Access_to_Resources', 
    'Extracurricular_Activities', 'Sleep_Hours', 'Previous_Scores', 'Motivation_Level', 
    'Internet_Access', 'Tutoring_Sessions', 'Family_Income', 'Teacher_Quality',
    'School_Type', 'Peer_Influence', 'Physical_Activity', 'Learning_Disabilities', 
    'Parental_Education_Level', 'Distance_from_Home', 'Gender', 'Exam_Score'
  ]);
  const handleOrder = (value) => setOrder(value);

  // Central query parameter object
  const [queryParameter, setQueryParameter] = useState({});
  useEffect(() => {
    setQueryParameter({
      Distance_from_Home: distanceFromHome,
      Parental_Education_Level: parentalEducationLevel,
      Teacher_Quality: teacherQuality,
      Family_Income: familyIncome,
      Motivation_Level: motivationLevel,
      Access_to_Resources: accessToResources,
      Parental_Involvement: parentalInvolvement,
      Learning_Disabilities: learningDisabilities,
      Peer_Influence: peerInfluence,
      Extracurricular_Activities: extracurricularActivities,
      bin_id: selectedBins,
      Gender: gender,
      ...(selectedIds.length > 0 && { id: selectedIds }) // Pass selected ids if any
    });
  }, [
    distanceFromHome,
    parentalEducationLevel,
    teacherQuality,
    familyIncome,
    motivationLevel,
    accessToResources,
    parentalInvolvement,
    learningDisabilities,
    peerInfluence,
    extracurricularActivities,
    selectedBins,
    gender,
    selectedIds
  ]);

  // Central data state
  const [data, setData] = useState([]);

  // Fetch data from API with all filters and selection
  useEffect(() => {
    const params = new URLSearchParams();
    Object.entries(queryParameter).forEach(([key, value]) => {
      if (Array.isArray(value)) value.forEach(v => params.append(key, v));
      else if (value !== undefined && value !== null) params.append(key, value);
    });
    const queryString = params.toString() ? `?${params.toString()}` : '';
    fetch(`http://127.0.0.1:5001/data${queryString}`)
      .then(res => res.json())
      .then(setData)
      .catch(err => setData([]));
  }, [queryParameter]);

  // Update functions
  const updateDistanceFromHome = arr => setDistanceFromHome(arr);
  const updateParentalEducationLevel = arr => setParentalEducationLevel(arr);
  const updateTeacherQuality = arr => setTeacherQuality(arr);
  const updateFamilyIncome = arr => setFamilyIncome(arr);
  const updateMotivationLevel = arr => setMotivationLevel(arr);
  const updateAccessToResources = arr => setAccessToResources(arr);
  const updateParentalInvolvement = arr => setParentalInvolvement(arr);
  const updateLearningDisabilities = arr => setLearningDisabilities(arr);
  const updatePeerInfluence = arr => setPeerInfluence(arr);
  const updateExtracurricularActivities = arr => setExtracurricularActivities(arr);
  const updateSelectedBins = arr => setSelectedBins(arr);
  const updateGender = arr => setGender(arr);

  // Handler for brushing in scatter plot
  const handleScatterBrush = (selectedPoints) => {
    setSelectedIds(selectedPoints);
  };

  return (
    <div className="bg-white text-black" style={{ position: 'relative', width: '1560px', height: '740px' }}>
      <h1 style={{ position: 'absolute', left: '50%', top: 5, transform: 'translateX(-50%)', fontSize: 18, fontWeight: 'bold', zIndex: 2 }}>
        STUDENT PERFORMANCE DASHBOARD
      </h1>
  
      {/* Top row */}
      <div style={{
        position: 'absolute', left: 20, top: 55, width: 450, height: 170, zIndex: 1,
        background: '#f9f9f9', borderRadius: 10, boxShadow: '0 2px 8px #0001'
      }}>
        <Histogram
          data={data}
          selectedBins={selectedBins}
          updateSelectedBins={updateSelectedBins}
        />
      </div>

      <div style={{
        position: 'absolute', left: 550, top: 55, width: 320, height: 275, zIndex: 1,
        background: '#f9f9f9', borderRadius: 10, boxShadow: '0 2px 8px #0001'
      }}>
        <RadarPlot
          initialFeatures={['Hours_Studied', 'Attendance', 'Sleep_Hours', 'Previous_Scores']}
          data={data}
        />
      </div>

      {/* HorizontalBarChart: big, stands for two rows */}
      <div style={{
        position: 'absolute', left: 970, top: 55, width: 580, height: 670, zIndex: 1,
        background: '#f9f9f9', borderRadius: 10, boxShadow: '0 2px 8px #0001'
      }}>
        <HorizontalBarChart
          data={data}
          variables={BarchartVariables}
          distanceFromHome={distanceFromHome}
          updateDistanceFromHome={updateDistanceFromHome}
          parentalEducationLevel={parentalEducationLevel}
          updateParentalEducationLevel={updateParentalEducationLevel}
          teacherQuality={teacherQuality}
          updateTeacherQuality={updateTeacherQuality}
          familyIncome={familyIncome}
          updateFamilyIncome={updateFamilyIncome}
          motivationLevel={motivationLevel}
          updateMotivationLevel={updateMotivationLevel}
          accessToResources={accessToResources}
          updateAccessToResources={updateAccessToResources}
          parentalInvolvement={parentalInvolvement}
          updateParentalInvolvement={updateParentalInvolvement}
          learningDisabilities={learningDisabilities}
          updateLearningDisabilities={updateLearningDisabilities}
          peerInfluence={peerInfluence}
          updatePeerInfluence={updatePeerInfluence}
          extracurricularActivities={extracurricularActivities}
          updateExtracurricularActivities={updateExtracurricularActivities}
          selectedBins={selectedBins}
        />
      </div>
  
      {/* Second row */}
      <div style={{
        position: 'absolute', left: 20, top: 238, width: 380, height: 190, zIndex: 1,
        background: '#f9f9f9', borderRadius: 10, boxShadow: '0 2px 8px #0001'
      }}>
        <LinePlot data={data} />
      </div>

      <div style={{
        position: 'absolute', left: 435, top: 360, width: 130, height: 360, zIndex: 1,
        background: '#f9f9f9', borderRadius: 10, boxShadow: '0 2px 8px #0001'
      }}>
        <Gender
          data={data}
          gender={gender}
          updateGender={updateGender}
        />
      </div>
  
      {/* Third row: PCPPlot full width */}
      <div style={{
        position: 'absolute', left: 25, top: 445, width: 370, height: 280, zIndex: 1,
        background: '#f9f9f9', borderRadius: 10, boxShadow: '0 2px 8px #0001'
      }}>
        <ScatterPlot
          data={data}
          numericFeatures={numericFeatures}
          onBrush={handleScatterBrush}
        />
      </div>
      {/* <div style={{
        position: 'absolute', left: 20, top: 600, width: 1510, height: 300, zIndex: 1,
        background: '#f9f9f9', borderRadius: 10, boxShadow: '0 2px 8px #0001'
      }}>
        <PCPPlot order={order} setOrder={handleOrder} data={data} />
      </div> */}
    </div>
  );
}
