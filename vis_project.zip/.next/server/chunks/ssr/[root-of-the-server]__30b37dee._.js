module.exports = {

"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[project]/src/components/histogram.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-ssr] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$bin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__histogram$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/bin.js [app-ssr] (ecmascript) <export default as histogram>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$extent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__extent$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/extent.js [app-ssr] (ecmascript) <export default as extent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__range$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/range.js [app-ssr] (ecmascript) <export default as range>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/band.js [app-ssr] (ecmascript) <export default as scaleBand>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-ssr] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/max.js [app-ssr] (ecmascript) <export default as max>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-axis/src/axis.js [app-ssr] (ecmascript)");
"use client";
;
;
;
const Histogram = ()=>{
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const fetchData = async ()=>{
            const response = await fetch('http://127.0.0.1:5001/data');
            const result = await response.json();
            setData(result);
        };
        fetchData();
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (data.length > 0) {
            const scores = data.map((d)=>d.Exam_Score);
            const margin = {
                top: 20,
                right: 30,
                bottom: 40,
                left: 40
            };
            const width = 400 - margin.left - margin.right;
            const height = 200 - margin.top - margin.bottom;
            // Clear previous SVG contents
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).selectAll("*").remove();
            const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).attr('width', width + margin.left + margin.right).attr('height', height + margin.top + margin.bottom).append('g').attr('transform', `translate(${margin.left},${margin.top})`);
            const histogram = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$bin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__histogram$3e$__["histogram"])().value((d)=>d).domain((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$extent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__extent$3e$__["extent"])(scores)).thresholds((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__range$3e$__["range"])(50, 102, 13));
            const bins = histogram(scores);
            const x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(bins.map((d)=>`${d.x0} - ${d.x1}`)).range([
                0,
                width
            ]).padding(0.1);
            const y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
                0,
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(bins, (d)=>d.length)
            ]).nice().range([
                height,
                0
            ]);
            // Create bars
            svg.selectAll('.bar').data(bins).enter().append('rect').attr('class', 'bar').attr('x', (d)=>x(`${d.x0} - ${d.x1}`)).attr('y', (d)=>y(d.length)).attr('width', x.bandwidth()).attr('height', (d)=>height - y(d.length)).attr('fill', 'steelblue');
            // Add text labels
            svg.selectAll('.bar-label').data(bins).enter().append('text').attr('class', 'bar-label').attr('x', (d)=>x(`${d.x0} - ${d.x1}`) + x.bandwidth() / 2).attr('y', (d)=>y(d.length) - 5) // 5px above bar top
            .attr('text-anchor', 'middle').style('fill', 'black').style('font-size', '10px').text((d)=>d.length);
            // X-axis
            svg.append('g').attr('transform', `translate(0,${height})`).call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["axisBottom"])(x));
        }
    }, [
        data
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        ref: svgRef
    }, void 0, false, {
        fileName: "[project]/src/components/histogram.js",
        lineNumber: 83,
        columnNumber: 10
    }, this);
};
const __TURBOPACK__default__export__ = Histogram;
}}),
"[project]/src/components/horizontalBarChart.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$group$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/group.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-ssr] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/max.js [app-ssr] (ecmascript) <export default as max>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-ssr] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/band.js [app-ssr] (ecmascript) <export default as scaleBand>");
"use client";
;
;
;
const HorizontalBarChart = ({ variables })=>{
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const fetchDataAndDraw = async ()=>{
            const response = await fetch('http://localhost:5001/data');
            const rawData = await response.json();
            // Process data client-side
            const processedData = variables.map((varName)=>({
                    varName,
                    counts: Array.from((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$group$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rollup"])(rawData, (v)=>v.length, (d)=>d[varName]), ([key, value])=>({
                            category: key,
                            count: value
                        })).sort((a, b)=>b.count - a.count)
                }));
            drawChart(processedData);
        };
        fetchDataAndDraw();
    }, [
        variables
    ]);
    const drawChart = (dataset)=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(ref.current).selectAll("*").remove();
        // Dimensions
        const width = 600, height = 600;
        const margin = {
            top: 30,
            right: 40,
            bottom: 120,
            left: 160
        };
        // Create SVG
        const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(ref.current).append('svg').attr('width', width).attr('height', height);
        // Process data
        const maxCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(dataset.flatMap((d)=>d.counts.map((c)=>c.count))) || 1;
        // Scales
        const xScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
            0,
            maxCount
        ]).range([
            margin.left,
            width - margin.right
        ]);
        const yScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(dataset.map((d)=>d.varName)).range([
            height - margin.bottom,
            margin.top
        ]).padding(0.2);
        // Create variable groups
        const variableGroups = svg.selectAll('.variable-group').data(dataset).enter().append('g').attr('transform', (d)=>`translate(0,${yScale(d.varName)})`);
        // Add bars and labels
        variableGroups.each(function(d) {
            const categoryScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(d.counts.map((c)=>c.category)).range([
                0,
                yScale.bandwidth()
            ]).padding(0.05);
            const group = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this);
            // Bars
            group.selectAll('rect').data(d.counts).enter().append('rect').attr('x', margin.left).attr('y', (c)=>categoryScale(c.category)).attr('width', (c)=>xScale(c.count) - margin.left).attr('height', categoryScale.bandwidth() * 0.95).attr('fill', '#4f46e5').attr('rx', 4);
            // Count labels (top of bars)
            group.selectAll('.count-label').data(d.counts).enter().append('text').attr('class', 'count-label').attr('x', (c)=>xScale(c.count) + 28).attr('y', (c)=>categoryScale(c.category) + 11).attr('text-anchor', 'end').style('font-size', '0.7em').style('fill', 'black').text((c)=>c.count);
            // Category labels (right side)
            group.selectAll('.category-label').data(d.counts).enter().append('text').attr('class', 'category-label').attr('x', (c)=>xScale(c.count) - 5).attr('y', (c)=>categoryScale(c.category) + categoryScale.bandwidth() / 2).attr('dy', '0.35em').attr('text-anchor', 'end').style('font-size', '0.7em').style('fill', 'white').text((c)=>c.category);
        });
        // Variable labels (multi-line)
        variableGroups.append('text').attr('x', margin.left - 15).attr('y', yScale.bandwidth() / 2 - 10).attr('text-anchor', 'end').attr('dominant-baseline', 'middle').style('font-size', '0.85em').selectAll('tspan').data((d)=>d.varName.split('_')).enter().append('tspan').attr('x', margin.left - 15).attr('dy', (d, i)=>i === 0 ? 0 : '1.2em').text((d)=>d.charAt(0).toUpperCase() + d.slice(1).toLowerCase());
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref
    }, void 0, false, {
        fileName: "[project]/src/components/horizontalBarChart.js",
        lineNumber: 127,
        columnNumber: 10
    }, this);
};
const __TURBOPACK__default__export__ = HorizontalBarChart;
}}),
"[project]/src/components/gender.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$group$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/group.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-ssr] (ecmascript) <export default as select>");
"use client";
;
;
;
const GenderDistribution = ()=>{
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const fetchDataAndDraw = async ()=>{
            const response = await fetch("http://localhost:5001/data");
            const data = await response.json();
            const genderCounts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$group$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rollup"])(data, (v)=>v.length, (d)=>d.Gender);
            const maleCount = genderCounts.get("Male") || 0;
            const femaleCount = genderCounts.get("Female") || 0;
            const total = maleCount + femaleCount;
            const malePct = total ? Math.round(maleCount / total * 100) : 0;
            const femalePct = total ? Math.round(femaleCount / total * 100) : 0;
            drawSvg(malePct, femalePct);
        };
        fetchDataAndDraw();
    }, []);
    function drawSvg(malePct, femalePct) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).selectAll("*").remove();
        const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).append("svg").attr("viewBox", "0 0 64 128").attr("width", 150).attr("height", 200);
        // --- CLIP PATHS ---
        const defs = svg.append("defs");
        // Male (left) percentage clip: fill up to percentage from bottom
        defs.append("clipPath").attr("id", "maleClip").append("rect").attr("x", 0).attr("y", 128 - 128 * malePct / 100).attr("width", 32).attr("height", 128 * malePct / 100);
        // Female (right) percentage clip: fill up to percentage from bottom
        defs.append("clipPath").attr("id", "femaleClip").append("rect").attr("x", 32).attr("y", 128 - 128 * femalePct / 100).attr("width", 32).attr("height", 128 * femalePct / 100);
        // --- FIGURE FILLS ---
        // Head - Left (Blue)
        svg.append("circle").attr("cx", 32).attr("cy", 16).attr("r", 12).attr("fill", "deepskyblue").attr("clip-path", "url(#maleClip)");
        // Head - Right (Pink)
        svg.append("circle").attr("cx", 32).attr("cy", 16).attr("r", 12).attr("fill", "hotpink").attr("clip-path", "url(#femaleClip)");
        // Male half (left side with straight torso and connected arm)
        svg.append("path").attr("d", "M20 28 L20 128 L24 128 L28 60 L28 28 Z").attr("fill", "deepskyblue").attr("clip-path", "url(#maleClip)");
        // Male Arm (connected)
        svg.append("path").attr("d", "M14 40 Q12 50, 14 70 L18 70 Q16 50, 18 40 Z").attr("fill", "deepskyblue").attr("clip-path", "url(#maleClip)");
        // Female half (right side with skirt and connected arm)
        svg.append("path").attr("d", "M32 28 L36 40 L48 80 L36 80 L40 128 L34 128 L32 80 L32 60 Z").attr("fill", "hotpink").attr("clip-path", "url(#femaleClip)");
        // Female Arm (connected)
        svg.append("path").attr("d", "M50 40 Q52 50, 50 70 L46 70 Q48 50, 46 40 Z").attr("fill", "hotpink").attr("clip-path", "url(#femaleClip)");
        // Fixing the white gaps in the female body (adding a pink section)
        svg.append("path").attr("d", "M32 60 L32 80 L34 80 L34 128 L40 128 L40 80 L48 80 Z").attr("fill", "hotpink").attr("clip-path", "url(#femaleClip)");
        // --- OUTLINE (always visible, black) ---
        svg.append("circle").attr("cx", 32).attr("cy", 16).attr("r", 12).attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        svg.append("path").attr("d", "M20 28 L20 128 L24 128 L28 60 L28 28 Z").attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        svg.append("path").attr("d", "M14 40 Q12 50, 14 70 L18 70 Q16 50, 18 40 Z").attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        svg.append("path").attr("d", "M32 28 L36 40 L48 80 L36 80 L40 128 L34 128 L32 80 L32 60 Z").attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        svg.append("path").attr("d", "M50 40 Q52 50, 50 70 L46 70 Q48 50, 46 40 Z").attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        svg.append("path").attr("d", "M32 60 L32 80 L34 80 L34 128 L40 128 L40 80 L48 80 Z").attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        // --- PERCENTAGE LABELS ---
        svg.append("text").attr("x", 6).attr("y", 70).attr("text-anchor", "middle").attr("font-size", "5px").attr("fill", "deepskyblue").attr("font-weight", "bold").text(`${malePct}%`);
        svg.append("text").attr("x", 58).attr("y", 70).attr("text-anchor", "middle").attr("font-size", "5px").attr("fill", "hotpink").attr("font-weight", "bold").text(`${femalePct}%`);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                style: {
                    marginBottom: 8
                },
                children: "Gender Distribution"
            }, void 0, false, {
                fileName: "[project]/src/components/gender.js",
                lineNumber: 193,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: svgRef
            }, void 0, false, {
                fileName: "[project]/src/components/gender.js",
                lineNumber: 194,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/gender.js",
        lineNumber: 192,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = GenderDistribution;
}}),
"[project]/src/components/PCPPlot.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-ssr] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__point__as__scalePoint$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/band.js [app-ssr] (ecmascript) <export point as scalePoint>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-ssr] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$extent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__extent$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/extent.js [app-ssr] (ecmascript) <export default as extent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$ordinal$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleOrdinal$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/ordinal.js [app-ssr] (ecmascript) <export default as scaleOrdinal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2d$chromatic$2f$src$2f$categorical$2f$category10$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__schemeCategory10$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale-chromatic/src/categorical/category10.js [app-ssr] (ecmascript) <export default as schemeCategory10>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/line.js [app-ssr] (ecmascript) <export default as line>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-axis/src/axis.js [app-ssr] (ecmascript)");
"use client";
;
;
;
const PCPPlot = ({ order, setOrder })=>{
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const k = 4; // Default value as instructed
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        fetch("http://127.0.0.1:5001/data").then((response)=>response.json()).then((json)=>setData(json)).catch((error)=>console.error("Error fetching data:", error));
    }, []);
    // Function to move a dimension left in the order array
    const moveAxisLeft = (dimension)=>{
        const currentIndex = order.indexOf(dimension);
        if (currentIndex <= 0) return; // Can't move left if already leftmost
        const newOrder = [
            ...order
        ];
        // Swap with the dimension to the left
        [newOrder[currentIndex], newOrder[currentIndex - 1]] = [
            newOrder[currentIndex - 1],
            newOrder[currentIndex]
        ];
        setOrder(newOrder);
    };
    // Function to move a dimension right in the order array
    const moveAxisRight = (dimension)=>{
        const currentIndex = order.indexOf(dimension);
        if (currentIndex >= order.length - 1) return; // Can't move right if already rightmost
        const newOrder = [
            ...order
        ];
        // Swap with the dimension to the right
        [newOrder[currentIndex], newOrder[currentIndex + 1]] = [
            newOrder[currentIndex + 1],
            newOrder[currentIndex]
        ];
        setOrder(newOrder);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (data.length === 0 || !order) return;
        const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current);
        svg.selectAll("*").remove();
        const margin = {
            top: 80,
            right: 30,
            bottom: 100,
            left: 10
        }, width = 1450 - margin.left - margin.right, height = 600 - margin.top - margin.bottom;
        const dimensions = [
            ...order
        ];
        const x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__point__as__scalePoint$3e$__["scalePoint"])().domain(dimensions).range([
            0,
            width
        ]).padding(1.5);
        const y = {};
        dimensions.forEach((dim)=>{
            if (typeof data[0][dim] === "number") {
                y[dim] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$extent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__extent$3e$__["extent"])(data, (d)=>+d[dim])).range([
                    height,
                    0
                ]);
            } else {
                y[dim] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__point__as__scalePoint$3e$__["scalePoint"])().domain([
                    ...new Set(data.map((d)=>d[dim]))
                ]).range([
                    height,
                    0
                ]);
            }
        });
        const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$ordinal$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleOrdinal$3e$__["scaleOrdinal"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2d$chromatic$2f$src$2f$categorical$2f$category10$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__schemeCategory10$3e$__["schemeCategory10"]);
        const line = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__["line"])().x((d)=>x(d.dimension)).y((d)=>y[d.dimension](d.value));
        const g = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);
        svg.append("text").attr("x", width / 2).attr("y", 30).attr("text-anchor", "middle").style("font-size", "24px").style("font-weight", "bold").text("PCP Plot");
        g.selectAll(".line").data(data).enter().append("path").attr("d", (d)=>line(dimensions.map((dim)=>({
                    dimension: dim,
                    value: d[dim]
                })))).style("fill", "none").style("stroke", (d)=>color(d.bin_id)).style("opacity", 0.7);
        const axisGroups = g.selectAll(".axis").data(dimensions).enter().append("g").attr("class", "axis").attr("transform", (d)=>`translate(${x(d)},0)`).each(function(d) {
            const axisGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this);
            axisGroup.call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["axisLeft"])(y[d]).tickSize(6).tickPadding(10));
            axisGroup.selectAll(".tick text").style("font-weight", "bold").each(function() {
                const text = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this);
                const words = text.text();
                text.text("");
                for(let i = 0; i < words.length; i += 14){
                    text.append("tspan").attr("x", 0).attr("dy", i === 0 ? "0em" : "1.2em").text(words.slice(i, i + 14));
                }
            });
        });
        g.selectAll(".axis line, .axis path").style("stroke", "black");
        // Add axis labels and reordering buttons
        const axisLabels = g.selectAll(".axis-label-container").data(dimensions).enter().append("g").attr("class", "axis-label-container").attr("transform", (d)=>`translate(${x(d)},${height + 30})`);
        // Add text labels
        axisLabels.append("text").attr("text-anchor", "middle").style("fill", "black").style("font-size", "14px").each(function(d) {
            if (d.length > 10) {
                const mid = Math.ceil(d.length / 2);
                const firstPart = d.slice(0, mid);
                const secondPart = d.slice(mid);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).append("tspan").attr("x", 0).attr("dy", "0em").text(firstPart);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).append("tspan").attr("x", 0).attr("dy", "1.2em").text(secondPart);
            } else {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).text(d);
            }
        });
        // Add left button for axis reordering
        axisLabels.append("rect").attr("class", "move-button left").attr("x", -30).attr("y", 25).attr("width", 20).attr("height", 20).attr("rx", 3).attr("fill", (d)=>order.indexOf(d) > 0 ? "steelblue" : "#ccc").style("cursor", (d)=>order.indexOf(d) > 0 ? "pointer" : "default").on("click", function(event, d) {
            if (order.indexOf(d) > 0) {
                event.stopPropagation();
                moveAxisLeft(d);
            }
        });
        // Add left button arrow
        axisLabels.append("text").attr("class", "move-button-text left").attr("x", -20).attr("y", 40).attr("text-anchor", "middle").attr("fill", "white").text("←").style("font-size", "14px").style("font-weight", "bold").style("pointer-events", "none"); // Make text non-interactive
        // Add right button for axis reordering
        axisLabels.append("rect").attr("class", "move-button right").attr("x", 10).attr("y", 25).attr("width", 20).attr("height", 20).attr("rx", 3).attr("fill", (d)=>order.indexOf(d) < order.length - 1 ? "steelblue" : "#ccc").style("cursor", (d)=>order.indexOf(d) < order.length - 1 ? "pointer" : "default").on("click", function(event, d) {
            if (order.indexOf(d) < order.length - 1) {
                event.stopPropagation();
                moveAxisRight(d);
            }
        });
        // Add right button arrow
        axisLabels.append("text").attr("class", "move-button-text right").attr("x", 20).attr("y", 40).attr("text-anchor", "middle").attr("fill", "white").text("→").style("font-size", "14px").style("font-weight", "bold").style("pointer-events", "none"); // Make text non-interactive
        // Add the legend
        const legend = svg.append("g").attr("transform", `translate(${width - 70}, 10)`);
        const uniqueClusters = [
            ...new Set(data.map((d)=>d.bin_id))
        ];
        uniqueClusters.forEach((cluster, i)=>{
            legend.append("circle").attr("cx", 0).attr("cy", i * 20).attr("r", 5).attr("fill", color(cluster));
            legend.append("text").attr("x", 10).attr("y", i * 20 + 4).text("cluster " + cluster).style("font-size", "12px").attr("alignment-baseline", "middle");
        });
    }, [
        data,
        order,
        setOrder
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            textAlign: "center"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            ref: svgRef,
            width: 1500,
            height: 600
        }, void 0, false, {
            fileName: "[project]/src/components/PCPPlot.js",
            lineNumber: 239,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/PCPPlot.js",
        lineNumber: 238,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = PCPPlot;
}}),
"[project]/src/app/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Home)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$histogram$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/histogram.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$horizontalBarChart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/horizontalBarChart.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$gender$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/gender.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PCPPlot$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PCPPlot.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
function Home() {
    const [order, setOrder] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        'Hours_Studied',
        'Attendance',
        'Parental_Involvement',
        'Access_to_Resources',
        'Extracurricular_Activities',
        'Sleep_Hours',
        'Previous_Scores',
        'Motivation_Level',
        'Internet_Access',
        'Tutoring_Sessions',
        'Family_Income',
        'Teacher_Quality',
        'School_Type',
        'Peer_Influence',
        'Physical_Activity',
        'Learning_Disabilities',
        'Parental_Education_Level',
        'Distance_from_Home',
        'Gender',
        'Exam_Score'
    ]);
    const corder = [
        'Hours_Studied',
        'Attendance',
        'Parental_Involvement',
        'Access_to_Resources',
        'Extracurricular_Activities',
        'Sleep_Hours',
        'Previous_Scores',
        'Motivation_Level',
        'Internet_Access',
        'Tutoring_Sessions',
        'Family_Income',
        'Teacher_Quality',
        'School_Type',
        'Peer_Influence',
        'Physical_Activity',
        'Learning_Disabilities',
        'Parental_Education_Level',
        'Distance_from_Home',
        'Gender',
        'Exam_Score'
    ];
    const BarchartVariables = [
        'Parental_Involvement',
        'Access_to_Resources',
        'Motivation_Level',
        'Family_Income',
        'Teacher_Quality',
        'Parental_Education_Level',
        'Distance_from_Home'
    ];
    const handleOrder = (value)=>{
        setOrder(value);
        console.log(order);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                children: "Student Performance Histogram"
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 25,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$histogram$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 26,
                columnNumber: 6
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$horizontalBarChart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                variables: BarchartVariables
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 27,
                columnNumber: 6
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$gender$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 28,
                columnNumber: 6
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PCPPlot$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                order: order,
                setOrder: handleOrder
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 29,
                columnNumber: 6
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__30b37dee._.js.map