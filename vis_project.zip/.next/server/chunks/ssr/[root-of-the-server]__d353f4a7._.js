module.exports = {

"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[project]/src/components/histogram.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-ssr] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/band.js [app-ssr] (ecmascript) <export default as scaleBand>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-ssr] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/max.js [app-ssr] (ecmascript) <export default as max>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-axis/src/axis.js [app-ssr] (ecmascript)");
"use client";
;
;
;
const BIN_RANGES = [
    {
        bin: 1,
        label: "50–64",
        range: [
            50,
            65
        ],
        color: "#4f46e5"
    },
    {
        bin: 2,
        label: "65–79",
        range: [
            65,
            80
        ],
        color: "#FFD600"
    },
    {
        bin: 3,
        label: "80–89",
        range: [
            80,
            90
        ],
        color: "#00C853"
    },
    {
        bin: 4,
        label: "90–100",
        range: [
            90,
            101
        ],
        color: "#FF1744"
    }
];
const Histogram = ({ data, selectedBins, updateSelectedBins })=>{
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!data) return;
        drawHistogram(data);
    }, [
        data,
        selectedBins
    ]);
    function drawHistogram(data) {
        const margin = {
            top: 50,
            right: 100,
            bottom: 60,
            left: 40
        };
        const width = 400 - margin.left - margin.right;
        const height = 200 - margin.top - margin.bottom;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).selectAll("*").remove();
        const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).attr('width', width + margin.left + margin.right).attr('height', height + margin.top + margin.bottom).append('g').attr('transform', `translate(${margin.left},${margin.top})`);
        const binCounts = BIN_RANGES.map(({ bin, range, label, color })=>({
                bin,
                label,
                color,
                count: data.filter((d)=>+d.Exam_Score >= range[0] && +d.Exam_Score < range[1]).length
            }));
        const x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(binCounts.map((b)=>b.label)).range([
            0,
            width
        ]).padding(0.1);
        const y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
            0,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(binCounts, (b)=>b.count) || 1
        ]).nice().range([
            height,
            0
        ]);
        const getFill = (binObj)=>{
            if (selectedBins.length === 0) return binObj.color;
            return selectedBins.includes(binObj.bin) ? binObj.color : "#ccc";
        };
        // Bars
        svg.selectAll(".bar").data(binCounts).enter().append("rect").attr("class", "bar").attr("x", (d)=>x(d.label)).attr("y", (d)=>y(d.count)).attr("width", x.bandwidth()).attr("height", (d)=>height - y(d.count)).attr("fill", getFill).style("cursor", "pointer").on("click", (event, d)=>{
            if (selectedBins.includes(d.bin)) {
                updateSelectedBins(selectedBins.filter((b)=>b !== d.bin));
            } else {
                updateSelectedBins([
                    ...selectedBins,
                    d.bin
                ].sort());
            }
        });
        // Value labels
        svg.selectAll(".bar-label").data(binCounts).enter().append("text").attr("class", "bar-label").attr("x", (d)=>x(d.label) + x.bandwidth() / 2).attr("y", (d)=>y(d.count) - 5).attr("text-anchor", "middle").style("font-size", "10px").text((d)=>d.count);
        // X-axis with ticks (labels) and clickable
        const xAxis = svg.append("g").attr("transform", `translate(0,${height})`).call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["axisBottom"])(x).tickSize(0));
        xAxis.selectAll("text").style("cursor", "pointer").attr("fill", (d)=>{
            const binObj = binCounts.find((b)=>b.label === d);
            return getFill(binObj);
        }).on("click", function(event, label) {
            const binObj = binCounts.find((b)=>b.label === label);
            if (!binObj) return;
            if (selectedBins.includes(binObj.bin)) {
                updateSelectedBins(selectedBins.filter((b)=>b !== binObj.bin));
            } else {
                updateSelectedBins([
                    ...selectedBins,
                    binObj.bin
                ].sort());
            }
        });
        // Remove x-axis line
        xAxis.select("path.domain").attr("stroke", "none");
        // X-axis label below the ticks
        svg.append("text").attr("x", width / 2).attr("y", height + 40).attr("text-anchor", "middle").style("font-size", "13px").style("font-weight", "bold").text("Exam Score Bin");
        // Y-axis label only (no ticks/numbers)
        svg.append("text").attr("transform", `rotate(-90)`).attr("x", -height / 2).attr("y", -15).attr("text-anchor", "middle").style("font-size", "13px").style("font-weight", "bold").text("Count");
        // Remove y-axis ticks and numbers
        svg.append("g").call((g)=>g.selectAll(".tick").remove()).call((g)=>g.selectAll("path.domain").remove());
        // Title
        svg.append("text").attr("x", width / 2).attr("y", -30).attr("text-anchor", "middle").style("font-size", "16px").style("font-weight", "bold").text("Exam Score Distribution");
        // Legend (spaced from bars)
        const legend = svg.append("g").attr("transform", `translate(${width + 20}, 0)`);
        BIN_RANGES.forEach((bin, i)=>{
            legend.append("rect").attr("x", 0).attr("y", i * 22).attr("width", 16).attr("height", 16).attr("fill", bin.color);
            legend.append("text").attr("x", 24).attr("y", i * 22 + 12).attr("font-size", "12px").attr("alignment-baseline", "middle").text(bin.label);
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        ref: svgRef
    }, void 0, false, {
        fileName: "[project]/src/components/histogram.js",
        lineNumber: 164,
        columnNumber: 10
    }, this);
};
const __TURBOPACK__default__export__ = Histogram;
}}),
"[project]/src/components/horizontalBarChart.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$group$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/group.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-ssr] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/max.js [app-ssr] (ecmascript) <export default as max>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-ssr] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/band.js [app-ssr] (ecmascript) <export default as scaleBand>");
"use client";
;
;
;
// Define all possible categories for each variable
const ALL_CATEGORIES = {
    Distance_from_Home: [
        "Near",
        "Moderate",
        "Far"
    ],
    Parental_Education_Level: [
        "High School",
        "College",
        "Postgraduate"
    ],
    Teacher_Quality: [
        "Low",
        "Medium",
        "High"
    ],
    Family_Income: [
        "Low",
        "Medium",
        "High"
    ],
    Motivation_Level: [
        "Low",
        "Medium",
        "High"
    ],
    Access_to_Resources: [
        "Low",
        "Medium",
        "High"
    ],
    Parental_Involvement: [
        "Low",
        "Medium",
        "High"
    ]
};
const HorizontalBarChart = ({ data, variables, distanceFromHome, updateDistanceFromHome, parentalEducationLevel, updateParentalEducationLevel, teacherQuality, updateTeacherQuality, familyIncome, updateFamilyIncome, motivationLevel, updateMotivationLevel, accessToResources, updateAccessToResources, parentalInvolvement, updateParentalInvolvement, selectedBins })=>{
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])();
    // Helper to get state array and updater for a variable
    const getStateAndUpdater = (varName)=>{
        switch(varName){
            case "Distance_from_Home":
                return [
                    distanceFromHome,
                    updateDistanceFromHome
                ];
            case "Parental_Education_Level":
                return [
                    parentalEducationLevel,
                    updateParentalEducationLevel
                ];
            case "Teacher_Quality":
                return [
                    teacherQuality,
                    updateTeacherQuality
                ];
            case "Family_Income":
                return [
                    familyIncome,
                    updateFamilyIncome
                ];
            case "Motivation_Level":
                return [
                    motivationLevel,
                    updateMotivationLevel
                ];
            case "Access_to_Resources":
                return [
                    accessToResources,
                    updateAccessToResources
                ];
            case "Parental_Involvement":
                return [
                    parentalInvolvement,
                    updateParentalInvolvement
                ];
            default:
                return [
                    [],
                    ()=>{}
                ];
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!data) return;
        const processedData = variables.map((varName)=>{
            const allCategories = ALL_CATEGORIES[varName] || [];
            const countsMap = new Map((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$group$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rollup"])(data, (v)=>v.length, (d)=>d[varName]));
            const counts = allCategories.map((cat)=>({
                    category: cat,
                    count: countsMap.get(cat) || 0
                }));
            return {
                varName,
                counts
            };
        });
        drawChart(processedData);
    }, [
        variables,
        distanceFromHome,
        parentalEducationLevel,
        teacherQuality,
        familyIncome,
        motivationLevel,
        accessToResources,
        parentalInvolvement,
        selectedBins
    ]);
    const drawChart = (dataset)=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(ref.current).selectAll("*").remove();
        // Dimensions
        const width = 600, height = 600;
        const margin = {
            top: 50,
            right: 40,
            bottom: 120,
            left: 100
        };
        // Create SVG
        const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(ref.current).append('svg').attr('width', width).attr('height', height);
        svg.append('text').attr('x', width / 2).attr('y', 30) // Position in top margin
        .attr('text-anchor', 'middle').style('font-size', '20px').style('font-weight', 'bold').text('Student Performance Factors Distribution');
        // Process data
        const maxCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(dataset.flatMap((d)=>d.counts.map((c)=>c.count))) || 1;
        // Scales
        const xScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
            0,
            maxCount
        ]).range([
            margin.left,
            width - margin.right
        ]);
        const yScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(dataset.map((d)=>d.varName)).range([
            height - margin.bottom,
            margin.top
        ]).padding(0.2);
        // Create variable groups
        const variableGroups = svg.selectAll('.variable-group').data(dataset).enter().append('g').attr('transform', (d)=>`translate(0,${yScale(d.varName)})`);
        // Add bars and labels
        variableGroups.each(function(d) {
            const [currentArray, updateArray] = getStateAndUpdater(d.varName);
            const categoryScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(d.counts.map((c)=>c.category)).range([
                0,
                yScale.bandwidth()
            ]).padding(0.05);
            const group = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this);
            // Bars
            group.selectAll('rect').data(d.counts).enter().append('rect').attr('x', margin.left).attr('y', (c)=>categoryScale(c.category)).attr('width', (c)=>Math.max(5, xScale(c.count) - margin.left)) // Ensure a minimum width for 0-count bars
            .attr('height', categoryScale.bandwidth() * 0.95).attr('fill', (c)=>currentArray.length === 0 || currentArray.includes(c.category) ? '#4f46e5' : '#ccc').attr('rx', 4).style('cursor', 'pointer').on('click', function(event, c) {
                event.stopPropagation();
                if (currentArray.includes(c.category)) {
                    updateArray(currentArray.filter((val)=>val !== c.category));
                } else {
                    updateArray([
                        ...currentArray,
                        c.category
                    ]);
                }
            });
            // Count labels (top of bars)
            group.selectAll('.count-label').data(d.counts).enter().append('text').attr('class', 'count-label').attr('x', (c)=>xScale(c.count) + 28).attr('y', (c)=>categoryScale(c.category) + 11).attr('text-anchor', 'end').style('font-size', '0.7em').style('fill', 'black').text((c)=>c.count);
            // Category labels (right side)
            group.selectAll('.category-label').data(d.counts).enter().append('text').attr('class', 'category-label').attr('x', (c)=>xScale(c.count) - 5).attr('y', (c)=>categoryScale(c.category) + categoryScale.bandwidth() / 2).attr('dy', '0.35em').attr('text-anchor', 'end').style('font-size', '0.7em').style('fill', 'white').text((c)=>c.category);
        });
        // Variable labels (multi-line)
        variableGroups.append('text').attr('x', margin.left - 15).attr('y', yScale.bandwidth() / 2 - 10).attr('text-anchor', 'end').attr('dominant-baseline', 'middle').style('font-size', '0.85em').selectAll('tspan').data((d)=>d.varName.split('_')).enter().append('tspan').attr('x', margin.left - 15).attr('dy', (d, i)=>i === 0 ? 0 : '1.2em').text((d)=>d.charAt(0).toUpperCase() + d.slice(1).toLowerCase());
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref
    }, void 0, false, {
        fileName: "[project]/src/components/horizontalBarChart.js",
        lineNumber: 181,
        columnNumber: 10
    }, this);
};
const __TURBOPACK__default__export__ = HorizontalBarChart;
}}),
"[project]/src/components/gender.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$group$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/group.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-ssr] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-ssr] (ecmascript) <export default as scaleLinear>");
"use client";
;
;
;
const GenderDistribution = ({ data, gender, updateGender, width = 150, height = 200 })=>{
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])();
    // Click handlers
    const handleMaleClick = (event)=>{
        event.preventDefault();
        event.stopPropagation();
        if (gender.includes("Male")) {
            updateGender(gender.filter((g)=>g !== "Male"));
        } else {
            updateGender([
                ...gender,
                "Male"
            ]);
        }
    };
    const handleFemaleClick = (event)=>{
        event.preventDefault();
        event.stopPropagation();
        if (gender.includes("Female")) {
            updateGender(gender.filter((g)=>g !== "Female"));
        } else {
            updateGender([
                ...gender,
                "Female"
            ]);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!data || !data.length) return;
        const genderCounts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$group$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rollup"])(data, (v)=>v.length, (d)=>d.Gender);
        const maleCount = genderCounts.get("Male") || 0;
        const femaleCount = genderCounts.get("Female") || 0;
        const total = maleCount + femaleCount;
        const malePct = total ? Math.round(maleCount / total * 100) : 0;
        const femalePct = total ? Math.round(femaleCount / total * 100) : 0;
        drawSvg(malePct, femalePct);
    // eslint-disable-next-line
    }, [
        data,
        gender,
        width,
        height
    ]);
    function drawSvg(malePct, femalePct) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).selectAll("*").remove();
        // Padding for title
        const titlePad = 20;
        const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).append("svg").attr("width", width).attr("height", height);
        // Title
        svg.append("text").attr("x", width / 2).attr("y", titlePad - 5).attr("text-anchor", "middle").attr("font-size", 0.08 * width).attr("font-weight", "bold").text("Gender Distribution");
        // Scales for figure
        const figX = 0.12 * width;
        const figY = titlePad;
        const figWidth = width * 0.75;
        const figHeight = height - titlePad - 10;
        // All geometry below is scaled to fit the SVG
        const scaleX = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
            0,
            64
        ]).range([
            figX,
            figX + figWidth
        ]);
        const scaleY = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
            0,
            128
        ]).range([
            figY,
            figY + figHeight
        ]);
        // --- CLIP PATHS ---
        const defs = svg.append("defs");
        defs.append("clipPath").attr("id", "maleClip").append("rect").attr("x", scaleX(0)).attr("y", scaleY(128 - 128 * malePct / 100)).attr("width", scaleX(32) - scaleX(0)).attr("height", scaleY(128 * malePct / 100) - scaleY(0));
        defs.append("clipPath").attr("id", "femaleClip").append("rect").attr("x", scaleX(32)).attr("y", scaleY(128 - 128 * femalePct / 100)).attr("width", scaleX(64) - scaleX(32)).attr("height", scaleY(128 * femalePct / 100) - scaleY(0));
        // Main color logic
        const maleFill = gender.length === 0 || gender.includes("Male") ? "deepskyblue" : "#ccc";
        const femaleFill = gender.length === 0 || gender.includes("Female") ? "hotpink" : "#ccc";
        // --- FIGURE FILLS ---
        svg.append("circle").attr("cx", scaleX(32)).attr("cy", scaleY(16)).attr("r", scaleX(44) - scaleX(32)).attr("fill", maleFill).attr("clip-path", "url(#maleClip)");
        svg.append("circle").attr("cx", scaleX(32)).attr("cy", scaleY(16)).attr("r", scaleX(44) - scaleX(32)).attr("fill", femaleFill).attr("clip-path", "url(#femaleClip)");
        svg.append("path").attr("d", `
        M${scaleX(20)} ${scaleY(28)} L${scaleX(20)} ${scaleY(128)} L${scaleX(24)} ${scaleY(128)} L${scaleX(28)} ${scaleY(60)} L${scaleX(28)} ${scaleY(28)} Z
      `).attr("fill", maleFill).attr("clip-path", "url(#maleClip)");
        svg.append("path").attr("d", `
        M${scaleX(14)} ${scaleY(40)} Q${scaleX(12)} ${scaleY(50)}, ${scaleX(14)} ${scaleY(70)}
        L${scaleX(18)} ${scaleY(70)} Q${scaleX(16)} ${scaleY(50)}, ${scaleX(18)} ${scaleY(40)} Z
      `).attr("fill", maleFill).attr("clip-path", "url(#maleClip)");
        svg.append("path").attr("d", `
        M${scaleX(32)} ${scaleY(28)} L${scaleX(36)} ${scaleY(40)} L${scaleX(48)} ${scaleY(80)} L${scaleX(36)} ${scaleY(80)}
        L${scaleX(40)} ${scaleY(128)} L${scaleX(34)} ${scaleY(128)} L${scaleX(32)} ${scaleY(80)} L${scaleX(32)} ${scaleY(60)} Z
      `).attr("fill", femaleFill).attr("clip-path", "url(#femaleClip)");
        svg.append("path").attr("d", `
        M${scaleX(50)} ${scaleY(40)} Q${scaleX(52)} ${scaleY(50)}, ${scaleX(50)} ${scaleY(70)}
        L${scaleX(46)} ${scaleY(70)} Q${scaleX(48)} ${scaleY(50)}, ${scaleX(46)} ${scaleY(40)} Z
      `).attr("fill", femaleFill).attr("clip-path", "url(#femaleClip)");
        svg.append("path").attr("d", `
        M${scaleX(32)} ${scaleY(60)} L${scaleX(32)} ${scaleY(80)} L${scaleX(34)} ${scaleY(80)}
        L${scaleX(34)} ${scaleY(128)} L${scaleX(40)} ${scaleY(128)} L${scaleX(40)} ${scaleY(80)} L${scaleX(48)} ${scaleY(80)} Z
      `).attr("fill", femaleFill).attr("clip-path", "url(#femaleClip)");
        // --- OUTLINE (always visible, black) ---
        svg.append("circle").attr("cx", scaleX(32)).attr("cy", scaleY(16)).attr("r", scaleX(44) - scaleX(32)).attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        svg.append("path").attr("d", `
        M${scaleX(20)} ${scaleY(28)} L${scaleX(20)} ${scaleY(128)} L${scaleX(24)} ${scaleY(128)} L${scaleX(28)} ${scaleY(60)} L${scaleX(28)} ${scaleY(28)} Z
      `).attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        svg.append("path").attr("d", `
        M${scaleX(14)} ${scaleY(40)} Q${scaleX(12)} ${scaleY(50)}, ${scaleX(14)} ${scaleY(70)}
        L${scaleX(18)} ${scaleY(70)} Q${scaleX(16)} ${scaleY(50)}, ${scaleX(18)} ${scaleY(40)} Z
      `).attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        svg.append("path").attr("d", `
        M${scaleX(32)} ${scaleY(28)} L${scaleX(36)} ${scaleY(40)} L${scaleX(48)} ${scaleY(80)} L${scaleX(36)} ${scaleY(80)}
        L${scaleX(40)} ${scaleY(128)} L${scaleX(34)} ${scaleY(128)} L${scaleX(32)} ${scaleY(80)} L${scaleX(32)} ${scaleY(60)} Z
      `).attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        svg.append("path").attr("d", `
        M${scaleX(50)} ${scaleY(40)} Q${scaleX(52)} ${scaleY(50)}, ${scaleX(50)} ${scaleY(70)}
        L${scaleX(46)} ${scaleY(70)} Q${scaleX(48)} ${scaleY(50)}, ${scaleX(46)} ${scaleY(40)} Z
      `).attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        svg.append("path").attr("d", `
        M${scaleX(32)} ${scaleY(60)} L${scaleX(32)} ${scaleY(80)} L${scaleX(34)} ${scaleY(80)}
        L${scaleX(34)} ${scaleY(128)} L${scaleX(40)} ${scaleY(128)} L${scaleX(40)} ${scaleY(80)} L${scaleX(48)} ${scaleY(80)} Z
      `).attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        // --- PERCENTAGE LABELS ---
        svg.append("text").attr("x", scaleX(6)).attr("y", scaleY(70)).attr("text-anchor", "middle").attr("font-size", "5px").attr("fill", maleFill).attr("font-weight", "bold").text(`${malePct}%`);
        svg.append("text").attr("x", scaleX(58)).attr("y", scaleY(70)).attr("text-anchor", "middle").attr("font-size", "5px").attr("fill", femaleFill).attr("font-weight", "bold").text(`${femalePct}%`);
        // Male side clickable area
        svg.append("rect").attr("x", scaleX(0)).attr("y", scaleY(0)).attr("width", scaleX(32) - scaleX(0)).attr("height", scaleY(128) - scaleY(0)).attr("fill", "transparent").style("cursor", "pointer").on("click", handleMaleClick).on("mouseover", function() {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).attr("fill", "rgba(0,0,0,0.05)");
        }).on("mouseout", function() {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).attr("fill", "transparent");
        });
        // Female side clickable area  
        svg.append("rect").attr("x", scaleX(32)).attr("y", scaleY(0)).attr("width", scaleX(64) - scaleX(32)).attr("height", scaleY(128) - scaleY(0)).attr("fill", "transparent").style("cursor", "pointer").on("click", handleFemaleClick).on("mouseover", function() {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).attr("fill", "rgba(0,0,0,0.05)");
        }).on("mouseout", function() {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).attr("fill", "transparent");
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: svgRef
    }, void 0, false, {
        fileName: "[project]/src/components/gender.js",
        lineNumber: 256,
        columnNumber: 10
    }, this);
};
const __TURBOPACK__default__export__ = GenderDistribution;
}}),
"[project]/src/components/PCPPlot.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-ssr] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__point__as__scalePoint$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/band.js [app-ssr] (ecmascript) <export point as scalePoint>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-ssr] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$extent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__extent$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/extent.js [app-ssr] (ecmascript) <export default as extent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$ordinal$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleOrdinal$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/ordinal.js [app-ssr] (ecmascript) <export default as scaleOrdinal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2d$chromatic$2f$src$2f$categorical$2f$category10$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__schemeCategory10$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale-chromatic/src/categorical/category10.js [app-ssr] (ecmascript) <export default as schemeCategory10>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/line.js [app-ssr] (ecmascript) <export default as line>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-axis/src/axis.js [app-ssr] (ecmascript)");
"use client";
;
;
;
const PCPPlot = ({ data, order, setOrder })=>{
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    //const k = 4; // Default value as instructed
    // Changed dependency to queryParameter
    // Function to move a dimension left in the order array
    const moveAxisLeft = (dimension)=>{
        const currentIndex = order.indexOf(dimension);
        if (currentIndex <= 0) return; // Can't move left if already leftmost
        const newOrder = [
            ...order
        ];
        // Swap with the dimension to the left
        [newOrder[currentIndex], newOrder[currentIndex - 1]] = [
            newOrder[currentIndex - 1],
            newOrder[currentIndex]
        ];
        setOrder(newOrder);
    };
    // Function to move a dimension right in the order array
    const moveAxisRight = (dimension)=>{
        const currentIndex = order.indexOf(dimension);
        if (currentIndex >= order.length - 1) return; // Can't move right if already rightmost
        const newOrder = [
            ...order
        ];
        // Swap with the dimension to the right
        [newOrder[currentIndex], newOrder[currentIndex + 1]] = [
            newOrder[currentIndex + 1],
            newOrder[currentIndex]
        ];
        setOrder(newOrder);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (data.length === 0 || !order) return;
        const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current);
        svg.selectAll("*").remove();
        const margin = {
            top: 80,
            right: 30,
            bottom: 100,
            left: 10
        }, width = 1450 - margin.left - margin.right, height = 600 - margin.top - margin.bottom;
        const dimensions = [
            ...order
        ];
        const x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__point__as__scalePoint$3e$__["scalePoint"])().domain(dimensions).range([
            0,
            width
        ]).padding(1.5);
        const y = {};
        dimensions.forEach((dim)=>{
            if (typeof data[0][dim] === "number") {
                y[dim] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$extent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__extent$3e$__["extent"])(data, (d)=>+d[dim])).range([
                    height,
                    0
                ]);
            } else {
                y[dim] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__point__as__scalePoint$3e$__["scalePoint"])().domain([
                    ...new Set(data.map((d)=>d[dim]))
                ]).range([
                    height,
                    0
                ]);
            }
        });
        const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$ordinal$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleOrdinal$3e$__["scaleOrdinal"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2d$chromatic$2f$src$2f$categorical$2f$category10$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__schemeCategory10$3e$__["schemeCategory10"]);
        const line = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__["line"])().x((d)=>x(d.dimension)).y((d)=>y[d.dimension](d.value));
        const g = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);
        svg.append("text").attr("x", width / 2).attr("y", 30).attr("text-anchor", "middle").style("font-size", "24px").style("font-weight", "bold").text("PCP Plot");
        g.selectAll(".line").data(data).enter().append("path").attr("d", (d)=>line(dimensions.map((dim)=>({
                    dimension: dim,
                    value: d[dim]
                })))).style("fill", "none").style("stroke", (d)=>color(d.bin_id)).style("opacity", 0.7);
        const axisGroups = g.selectAll(".axis").data(dimensions).enter().append("g").attr("class", "axis").attr("transform", (d)=>`translate(${x(d)},0)`).each(function(d) {
            const axisGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this);
            axisGroup.call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["axisLeft"])(y[d]).tickSize(6).tickPadding(10));
            axisGroup.selectAll(".tick text").style("font-weight", "bold").each(function() {
                const text = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this);
                const words = text.text();
                text.text("");
                for(let i = 0; i < words.length; i += 14){
                    text.append("tspan").attr("x", 0).attr("dy", i === 0 ? "0em" : "1.2em").text(words.slice(i, i + 14));
                }
            });
        });
        g.selectAll(".axis line, .axis path").style("stroke", "black");
        // Add axis labels and reordering buttons
        const axisLabels = g.selectAll(".axis-label-container").data(dimensions).enter().append("g").attr("class", "axis-label-container").attr("transform", (d)=>`translate(${x(d)},${height + 30})`);
        // Add text labels
        axisLabels.append("text").attr("text-anchor", "middle").style("fill", "black").style("font-size", "14px").each(function(d) {
            if (d.length > 10) {
                const mid = Math.ceil(d.length / 2);
                const firstPart = d.slice(0, mid);
                const secondPart = d.slice(mid);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).append("tspan").attr("x", 0).attr("dy", "0em").text(firstPart);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).append("tspan").attr("x", 0).attr("dy", "1.2em").text(secondPart);
            } else {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).text(d);
            }
        });
        // Add left button for axis reordering
        axisLabels.append("rect").attr("class", "move-button left").attr("x", -30).attr("y", 25).attr("width", 20).attr("height", 20).attr("rx", 3).attr("fill", (d)=>order.indexOf(d) > 0 ? "steelblue" : "#ccc").style("cursor", (d)=>order.indexOf(d) > 0 ? "pointer" : "default").on("click", function(event, d) {
            if (order.indexOf(d) > 0) {
                event.stopPropagation();
                moveAxisLeft(d);
            }
        });
        // Add left button arrow - Changed fill to white for better contrast
        axisLabels.append("text").attr("class", "move-button-text left").attr("x", -20).attr("y", 40).attr("text-anchor", "middle").attr("fill", "white") // Changed from black to white
        .text("←").style("font-size", "14px").style("font-weight", "bold").style("pointer-events", "none"); // Make text non-interactive
        // Add right button for axis reordering
        axisLabels.append("rect").attr("class", "move-button right").attr("x", 10).attr("y", 25).attr("width", 20).attr("height", 20).attr("rx", 3).attr("fill", (d)=>order.indexOf(d) < order.length - 1 ? "steelblue" : "#ccc").style("cursor", (d)=>order.indexOf(d) < order.length - 1 ? "pointer" : "default").on("click", function(event, d) {
            if (order.indexOf(d) < order.length - 1) {
                event.stopPropagation();
                moveAxisRight(d);
            }
        });
        // Add right button arrow - Changed fill to white for better contrast
        axisLabels.append("text").attr("class", "move-button-text right").attr("x", 20).attr("y", 40).attr("text-anchor", "middle").attr("fill", "white") // Changed from black to white
        .text("→").style("font-size", "14px").style("font-weight", "bold").style("pointer-events", "none"); // Make text non-interactive
        // Add the legend
        const legend = svg.append("g").attr("transform", `translate(${width - 70}, 10)`);
        const uniqueClusters = [
            ...new Set(data.map((d)=>d.bin_id))
        ];
        uniqueClusters.forEach((cluster, i)=>{
            legend.append("circle").attr("cx", 0).attr("cy", i * 20).attr("r", 5).attr("fill", color(cluster));
            legend.append("text").attr("x", 10).attr("y", i * 20 + 4).text("cluster " + cluster).style("font-size", "12px").attr("alignment-baseline", "middle");
        });
    }, [
        data,
        order,
        setOrder
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            textAlign: "center"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            ref: svgRef,
            width: 1500,
            height: 600
        }, void 0, false, {
            fileName: "[project]/src/components/PCPPlot.js",
            lineNumber: 232,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/PCPPlot.js",
        lineNumber: 231,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = PCPPlot;
}}),
"[project]/src/components/scatterPlot.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-ssr] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-ssr] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/min.js [app-ssr] (ecmascript) <export default as min>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/max.js [app-ssr] (ecmascript) <export default as max>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$brush$2f$src$2f$brush$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__brush$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-brush/src/brush.js [app-ssr] (ecmascript) <export default as brush>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-axis/src/axis.js [app-ssr] (ecmascript)");
"use client";
;
;
;
const ScatterPlotMatrix = ({ numericFeatures, data, onBrush })=>{
    const [xIndex, setXIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [yIndex, setYIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(1);
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])();
    // Navigation handlers
    const moveXLeft = ()=>setXIndex((prev)=>prev > 0 ? prev - 1 : numericFeatures.length - 1);
    const moveXRight = ()=>setXIndex((prev)=>prev < numericFeatures.length - 1 ? prev + 1 : 0);
    const moveYLeft = ()=>setYIndex((prev)=>prev > 0 ? prev - 1 : numericFeatures.length - 1);
    const moveYRight = ()=>setYIndex((prev)=>prev < numericFeatures.length - 1 ? prev + 1 : 0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!data.length || !numericFeatures) return;
        const xFeature = numericFeatures[xIndex];
        const yFeature = numericFeatures[yIndex];
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).selectAll("*").remove();
        const binColors = {
            1: "#4f46e5",
            2: "#FFD600",
            3: "#00C853",
            4: "#FF1744" // red
        };
        const margin = {
            top: 50,
            right: 50,
            bottom: 50,
            left: 60
        };
        const width = 380 - margin.left - margin.right;
        const height = 240 - margin.top - margin.bottom;
        const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).attr('width', width + margin.left + margin.right).attr('height', height + margin.top + margin.bottom).append('g').attr('transform', `translate(${margin.left},${margin.top})`);
        const x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__["min"])(data, (d)=>+d[xFeature]) * 0.9,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(data, (d)=>+d[xFeature]) * 1.1
        ]).range([
            0,
            width
        ]);
        const y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__["min"])(data, (d)=>+d[yFeature]) * 0.9,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(data, (d)=>+d[yFeature]) * 1.1
        ]).range([
            height,
            0
        ]);
        // Brushing
        const brush = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$brush$2f$src$2f$brush$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__brush$3e$__["brush"])().extent([
            [
                0,
                0
            ],
            [
                width,
                height
            ]
        ]).on('end', (event)=>{
            if (!event.selection) {
                onBrush([]);
                return;
            }
            const [[x0, y0], [x1, y1]] = event.selection;
            const selectedPoints = data.filter((d)=>{
                const cx = x(+d[xFeature]);
                const cy = y(+d[yFeature]);
                return cx >= x0 && cx <= x1 && cy >= y0 && cy <= y1;
            });
            onBrush(selectedPoints.map((d)=>d.id));
        });
        svg.append("g").attr("class", "brush").call(brush);
        // Points
        svg.selectAll('circle').data(data).enter().append('circle').attr('cx', (d)=>x(+d[xFeature])).attr('cy', (d)=>y(+d[yFeature])).attr('r', 4).style('fill', (d)=>binColors[d.bin_id] || '#bbb').style('opacity', 0.7);
        // X axis
        svg.append('g').attr('transform', `translate(0,${height})`).call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["axisBottom"])(x));
        // Y axis
        svg.append('g').call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["axisLeft"])(y));
        // X axis navigation
        const xAxisLabel = svg.append('g').attr('transform', `translate(${width / 2}, ${height + 40})`);
        xAxisLabel.append('rect').attr('x', -85).attr('y', -15).attr('width', 20).attr('height', 20).attr('rx', 3).attr('fill', 'steelblue').style('cursor', 'pointer').on('click', moveXLeft);
        xAxisLabel.append('text').attr('x', -75).attr('y', 0).attr('text-anchor', 'middle').attr('fill', 'white').style('pointer-events', 'none').text('←');
        xAxisLabel.append('text').attr('x', 0).attr('y', 0).attr('text-anchor', 'middle').style('font-weight', 'bold').text(xFeature);
        xAxisLabel.append('rect').attr('x', 65).attr('y', -15).attr('width', 20).attr('height', 20).attr('rx', 3).attr('fill', 'steelblue').style('cursor', 'pointer').on('click', moveXRight);
        xAxisLabel.append('text').attr('x', 75).attr('y', 0).attr('text-anchor', 'middle').attr('fill', 'white').style('pointer-events', 'none').text('→');
        // Y axis navigation
        const yAxisLabel = svg.append('g').attr('transform', `translate(${-40}, ${height / 2}) rotate(-90)`);
        yAxisLabel.append('rect').attr('x', -85).attr('y', -15).attr('width', 20).attr('height', 20).attr('rx', 3).attr('fill', 'steelblue').style('cursor', 'pointer').on('click', moveYLeft);
        yAxisLabel.append('text').attr('x', -75).attr('y', 0).attr('text-anchor', 'middle').attr('fill', 'white').style('pointer-events', 'none').text('←');
        yAxisLabel.append('text').attr('x', 0).attr('y', 0).attr('text-anchor', 'middle').style('font-weight', 'bold').text(yFeature);
        yAxisLabel.append('rect').attr('x', 65).attr('y', -15).attr('width', 20).attr('height', 20).attr('rx', 3).attr('fill', 'steelblue').style('cursor', 'pointer').on('click', moveYRight);
        yAxisLabel.append('text').attr('x', 75).attr('y', 0).attr('text-anchor', 'middle').attr('fill', 'white').style('pointer-events', 'none').text('→');
        // Title
        svg.append('text').attr('x', width / 2).attr('y', -25).attr('text-anchor', 'middle').style('font-size', '16px').style('font-weight', 'bold').text(`${yFeature} vs ${xFeature}`);
    }, [
        data,
        xIndex,
        yIndex,
        numericFeatures,
        onBrush
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col items-center",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            ref: svgRef,
            width: 380,
            height: 240
        }, void 0, false, {
            fileName: "[project]/src/components/scatterPlot.js",
            lineNumber: 141,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/scatterPlot.js",
        lineNumber: 140,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = ScatterPlotMatrix;
}}),
"[project]/src/components/radarPlot.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-ssr] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$mean$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__mean$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/mean.js [app-ssr] (ecmascript) <export default as mean>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/max.js [app-ssr] (ecmascript) <export default as max>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-ssr] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/line.js [app-ssr] (ecmascript) <export default as line>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$curve$2f$linearClosed$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__curveLinearClosed$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/curve/linearClosed.js [app-ssr] (ecmascript) <export default as curveLinearClosed>");
"use client";
;
;
;
const RadarPlot = ({ initialFeatures, data })=>{
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])();
    const [features, setFeatures] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initialFeatures || [
        'Hours_Studied',
        'Attendance',
        'Sleep_Hours',
        'Previous_Scores'
    ]);
    const numericFeatures = [
        'Hours_Studied',
        'Attendance',
        'Sleep_Hours',
        'Previous_Scores',
        'Physical_Activity',
        'Tutoring_Sessions',
        'Exam_Score'
    ];
    const changeFeature = (index, direction)=>{
        setFeatures((prev)=>{
            const newFeatures = [
                ...prev
            ];
            const currIndex = numericFeatures.indexOf(prev[index]);
            const newIndex = (currIndex + direction + numericFeatures.length) % numericFeatures.length;
            newFeatures[index] = numericFeatures[newIndex];
            return newFeatures;
        });
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!data.length) return;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).selectAll("*").remove();
        const width = 350, height = 200;
        const margin = 0;
        const radius = Math.min(width, height) / 2 - margin;
        const levels = 3;
        const colors = {
            1: "#FF7676",
            2: "#FFB876",
            3: "#4F97FF",
            4: "#76FF8A"
        };
        const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).append("svg").attr("width", width).attr("height", height).append("g").attr("transform", `translate(${width / 2},${height / 2})`);
        // Add title
        svg.append("text").attr("x", 0).attr("y", -height / 2 + 20).attr("text-anchor", "middle").style("font-size", "14px").style("font-weight", "bold").text("Performance Radar");
        const dataBins = {};
        for(let bin = 1; bin <= 4; bin++){
            const binData = data.filter((d)=>{
                const score = +d.Exam_Score;
                if (bin === 1) return score >= 50 && score < 65;
                if (bin === 2) return score >= 65 && score < 80;
                if (bin === 3) return score >= 80 && score < 90;
                if (bin === 4) return score >= 90 && score <= 100;
                return false;
            });
            dataBins[bin] = features.map((feat)=>({
                    feature: feat,
                    value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$mean$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__mean$3e$__["mean"])(binData, (d)=>+d[feat]) || 0
                }));
        }
        const featureScales = {};
        const featureMaxes = {};
        features.forEach((feat)=>{
            const max = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(data, (d)=>+d[feat]) * 1.1;
            featureMaxes[feat] = max;
            featureScales[feat] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
                0,
                max
            ]).range([
                0,
                radius
            ]);
        });
        const angleSlice = Math.PI * 2 / features.length;
        // Draw 3 levels
        for(let level = 1; level <= levels; level++){
            const r = radius / levels * level;
            svg.append("circle").attr("cx", 0).attr("cy", 0).attr("r", r).attr("fill", "none").attr("stroke", "#ccc").attr("stroke-width", 1);
        }
        // Axes and labels
        for(let i = 0; i < features.length; i++){
            const angle = i * angleSlice - Math.PI / 2;
            const lineX = radius * Math.cos(angle);
            const lineY = radius * Math.sin(angle);
            svg.append("line").attr("x1", 0).attr("y1", 0).attr("x2", lineX).attr("y2", lineY).attr("stroke", "#999").attr("stroke-width", 1);
            // Multiline labels
            const label = features[i];
            const words = label.split('_');
            const labelG = svg.append("g").attr("transform", `translate(${1.15 * lineX},${1.15 * lineY})`);
            labelG.selectAll("tspan").data(words).enter().append("text").attr("text-anchor", "middle").attr("dy", (d, i)=>i * 12).style("font-size", "8px").text((d)=>d);
            // Feature controls
            labelG.append("circle").attr("cx", -30).attr("cy", 0).attr("r", 6).attr("fill", "steelblue").style("cursor", "pointer").on("click", ()=>changeFeature(i, -1));
            labelG.append("text").attr("x", -30).attr("y", 3).attr("text-anchor", "middle").text("←").style("fill", "white").style("font-size", "8px");
            labelG.append("circle").attr("cx", 30).attr("cy", 0).attr("r", 6).attr("fill", "steelblue").style("cursor", "pointer").on("click", ()=>changeFeature(i, 1));
            labelG.append("text").attr("x", 30).attr("y", 3).attr("text-anchor", "middle").text("→").style("fill", "white").style("font-size", "8px");
        }
        // Draw data polygons
        Object.entries(dataBins).forEach(([bin, binData])=>{
            const points = binData.map((d, i)=>{
                const angle = i * angleSlice - Math.PI / 2;
                const scale = featureScales[d.feature];
                return {
                    x: scale(d.value) * Math.cos(angle),
                    y: scale(d.value) * Math.sin(angle)
                };
            });
            svg.append("path").datum(points).attr("d", (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__["line"])().x((d)=>d.x).y((d)=>d.y).curve(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$curve$2f$linearClosed$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__curveLinearClosed$3e$__["curveLinearClosed"])).attr("fill", colors[bin]).attr("fill-opacity", 0.3).attr("stroke", colors[bin]).attr("stroke-width", 1.5);
        });
    }, [
        data,
        features
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: svgRef
    }, void 0, false, {
        fileName: "[project]/src/components/radarPlot.js",
        lineNumber: 182,
        columnNumber: 10
    }, this);
};
const __TURBOPACK__default__export__ = RadarPlot;
}}),
"[project]/src/app/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Home)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$histogram$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/histogram.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$horizontalBarChart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/horizontalBarChart.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$gender$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/gender.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PCPPlot$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PCPPlot.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$scatterPlot$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/scatterPlot.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$radarPlot$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/radarPlot.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
function Home() {
    // Filter states
    const [distanceFromHome, setDistanceFromHome] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [parentalEducationLevel, setParentalEducationLevel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [teacherQuality, setTeacherQuality] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [familyIncome, setFamilyIncome] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [motivationLevel, setMotivationLevel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [accessToResources, setAccessToResources] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [parentalInvolvement, setParentalInvolvement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedBins, setSelectedBins] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [gender, setGender] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedIds, setSelectedIds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]); // <-- For brushing/selection
    // BarchartVariables array for bar chart
    const BarchartVariables = [
        'Parental_Involvement',
        'Access_to_Resources',
        'Motivation_Level',
        'Family_Income',
        'Teacher_Quality',
        'Parental_Education_Level',
        'Distance_from_Home'
    ];
    // Numeric features for scatter/radar
    const numericFeatures = [
        'Hours_Studied',
        'Attendance',
        'Sleep_Hours',
        'Previous_Scores',
        'Tutoring_Sessions',
        'Physical_Activity',
        'Exam_Score'
    ];
    // PCP order handler
    const [order, setOrder] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        'Hours_Studied',
        'Attendance',
        'Parental_Involvement',
        'Access_to_Resources',
        'Extracurricular_Activities',
        'Sleep_Hours',
        'Previous_Scores',
        'Motivation_Level',
        'Internet_Access',
        'Tutoring_Sessions',
        'Family_Income',
        'Teacher_Quality',
        'School_Type',
        'Peer_Influence',
        'Physical_Activity',
        'Learning_Disabilities',
        'Parental_Education_Level',
        'Distance_from_Home',
        'Gender',
        'Exam_Score'
    ]);
    const handleOrder = (value)=>setOrder(value);
    // Central query parameter object
    const [queryParameter, setQueryParameter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setQueryParameter({
            Distance_from_Home: distanceFromHome,
            Parental_Education_Level: parentalEducationLevel,
            Teacher_Quality: teacherQuality,
            Family_Income: familyIncome,
            Motivation_Level: motivationLevel,
            Access_to_Resources: accessToResources,
            Parental_Involvement: parentalInvolvement,
            bin_id: selectedBins,
            Gender: gender,
            ...selectedIds.length > 0 && {
                id: selectedIds
            }
        });
    }, [
        distanceFromHome,
        parentalEducationLevel,
        teacherQuality,
        familyIncome,
        motivationLevel,
        accessToResources,
        parentalInvolvement,
        selectedBins,
        gender,
        selectedIds
    ]);
    // Central data state
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    // Fetch data from API with all filters and selection
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const params = new URLSearchParams();
        Object.entries(queryParameter).forEach(([key, value])=>{
            if (Array.isArray(value)) value.forEach((v)=>params.append(key, v));
            else if (value !== undefined && value !== null) params.append(key, value);
        });
        const queryString = params.toString() ? `?${params.toString()}` : '';
        fetch(`http://127.0.0.1:5001/data${queryString}`).then((res)=>res.json()).then(setData).catch((err)=>setData([]));
    }, [
        queryParameter
    ]);
    // Update functions
    const updateDistanceFromHome = (arr)=>setDistanceFromHome(arr);
    const updateParentalEducationLevel = (arr)=>setParentalEducationLevel(arr);
    const updateTeacherQuality = (arr)=>setTeacherQuality(arr);
    const updateFamilyIncome = (arr)=>setFamilyIncome(arr);
    const updateMotivationLevel = (arr)=>setMotivationLevel(arr);
    const updateAccessToResources = (arr)=>setAccessToResources(arr);
    const updateParentalInvolvement = (arr)=>setParentalInvolvement(arr);
    const updateSelectedBins = (arr)=>setSelectedBins(arr);
    const updateGender = (arr)=>setGender(arr);
    // Handler for brushing in scatter plot
    // Pass array of ids (e.g. selectedPoints.map(d => d.id))
    const handleScatterBrush = (selectedPoints)=>{
        setSelectedIds(selectedPoints);
    };
    // return (
    //   <div className="bg-white text-black">
    //     <h1>Student Performance Dashboard</h1>
    //     <Histogram 
    //       data={data}
    //       selectedBins={selectedBins}
    //       updateSelectedBins={updateSelectedBins}
    //     />
    //     <HorizontalBarChart 
    //       data={data}
    //       variables={BarchartVariables}
    //       distanceFromHome={distanceFromHome}
    //       updateDistanceFromHome={updateDistanceFromHome}
    //       parentalEducationLevel={parentalEducationLevel}
    //       updateParentalEducationLevel={updateParentalEducationLevel}
    //       teacherQuality={teacherQuality}
    //       updateTeacherQuality={updateTeacherQuality}
    //       familyIncome={familyIncome}
    //       updateFamilyIncome={updateFamilyIncome}
    //       motivationLevel={motivationLevel}
    //       updateMotivationLevel={updateMotivationLevel}
    //       accessToResources={accessToResources}
    //       updateAccessToResources={updateAccessToResources}
    //       parentalInvolvement={parentalInvolvement}
    //       updateParentalInvolvement={updateParentalInvolvement}
    //       selectedBins={selectedBins}
    //     />
    //     <Gender 
    //       data={data}
    //       gender={gender}
    //       updateGender={updateGender}
    //     />
    //     <PCPPlot order={order} setOrder={handleOrder} data={data} />
    //     <LinePlot data={data} />
    //     <ScatterPlot 
    //       data={data}
    //       numericFeatures={numericFeatures}
    //       onBrush={handleScatterBrush} 
    //     />
    //     <RadarPlot initialFeatures={['Hours_Studied','Attendance','Sleep_Hours', 'Previous_Scores']} data={data} />
    //   </div>
    // );
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white text-black",
        style: {
            position: 'relative',
            width: '1800px',
            height: '1200px'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                style: {
                    position: 'absolute',
                    left: 20,
                    top: 10,
                    fontSize: 32,
                    fontWeight: 'bold',
                    zIndex: 2
                },
                children: "Student Performance Dashboard"
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 167,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 20,
                    top: 60,
                    width: 380,
                    height: 200,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$histogram$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    data: data,
                    selectedBins: selectedBins,
                    updateSelectedBins: updateSelectedBins
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 176,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 172,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 420,
                    top: 60,
                    width: 170,
                    height: 200,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$gender$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    data: data,
                    gender: gender,
                    updateGender: updateGender
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 186,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 182,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 610,
                    top: 60,
                    width: 350,
                    height: 200,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                }
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 192,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 980,
                    top: 60,
                    width: 650,
                    height: 510,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$horizontalBarChart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    data: data,
                    variables: BarchartVariables,
                    distanceFromHome: distanceFromHome,
                    updateDistanceFromHome: updateDistanceFromHome,
                    parentalEducationLevel: parentalEducationLevel,
                    updateParentalEducationLevel: updateParentalEducationLevel,
                    teacherQuality: teacherQuality,
                    updateTeacherQuality: updateTeacherQuality,
                    familyIncome: familyIncome,
                    updateFamilyIncome: updateFamilyIncome,
                    motivationLevel: motivationLevel,
                    updateMotivationLevel: updateMotivationLevel,
                    accessToResources: accessToResources,
                    updateAccessToResources: updateAccessToResources,
                    parentalInvolvement: parentalInvolvement,
                    updateParentalInvolvement: updateParentalInvolvement,
                    selectedBins: selectedBins
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 203,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 199,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 20,
                    top: 330,
                    width: 540,
                    height: 270,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$radarPlot$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    initialFeatures: [
                        'Hours_Studied',
                        'Attendance',
                        'Sleep_Hours',
                        'Previous_Scores'
                    ],
                    data: data
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 229,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 225,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 580,
                    top: 330,
                    width: 380,
                    height: 240,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$scatterPlot$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    data: data,
                    numericFeatures: numericFeatures,
                    onBrush: handleScatterBrush
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 238,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 234,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 20,
                    top: 620,
                    width: 1710,
                    height: 300,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PCPPlot$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    order: order,
                    setOrder: handleOrder,
                    data: data
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 251,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 247,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 166,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__d353f4a7._.js.map