(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/components/histogram.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-client] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/band.js [app-client] (ecmascript) <export default as scaleBand>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-client] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/max.js [app-client] (ecmascript) <export default as max>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-axis/src/axis.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const BIN_RANGES = [
    {
        bin: 1,
        label: "50–64",
        range: [
            50,
            65
        ],
        color: "#4f46e5"
    },
    {
        bin: 2,
        label: "65–79",
        range: [
            65,
            80
        ],
        color: "#FFD600"
    },
    {
        bin: 3,
        label: "80–89",
        range: [
            80,
            90
        ],
        color: "#00C853"
    },
    {
        bin: 4,
        label: "90–100",
        range: [
            90,
            101
        ],
        color: "#FF1744"
    }
];
const Histogram = ({ data, selectedBins, updateSelectedBins })=>{
    _s();
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Histogram.useEffect": ()=>{
            if (!data) return;
            drawHistogram(data);
        }
    }["Histogram.useEffect"], [
        data,
        selectedBins
    ]);
    function drawHistogram(data) {
        const margin = {
            top: 50,
            right: 100,
            bottom: 60,
            left: 40
        };
        const width = 400 - margin.left - margin.right;
        const height = (200 - margin.top - margin.bottom) * 0.9; // Reduced height by 10%
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).selectAll("*").remove();
        const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).attr('width', width + margin.left + margin.right).attr('height', height + margin.top + margin.bottom).append('g').attr('transform', `translate(${margin.left},${margin.top})`);
        const binCounts = BIN_RANGES.map(({ bin, range, label, color })=>({
                bin,
                label,
                color,
                count: data.filter((d)=>+d.Exam_Score >= range[0] && +d.Exam_Score < range[1]).length
            }));
        const x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(binCounts.map((b)=>b.label)).range([
            0,
            width
        ]).padding(0.1);
        const y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
            0,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(binCounts, (b)=>b.count) || 1
        ]).nice().range([
            height,
            0
        ]);
        const getFill = (binObj)=>{
            if (selectedBins.length === 0) return binObj.color;
            return selectedBins.includes(binObj.bin) ? binObj.color : "#ccc";
        };
        // Bars
        svg.selectAll(".bar").data(binCounts).enter().append("rect").attr("class", "bar").attr("x", (d)=>x(d.label)).attr("y", (d)=>y(d.count)).attr("width", x.bandwidth()).attr("height", (d)=>height - y(d.count)).attr("fill", getFill).style("cursor", "pointer").on("click", (event, d)=>{
            if (selectedBins.includes(d.bin)) {
                updateSelectedBins(selectedBins.filter((b)=>b !== d.bin));
            } else {
                updateSelectedBins([
                    ...selectedBins,
                    d.bin
                ].sort());
            }
        });
        // Value labels
        svg.selectAll(".bar-label").data(binCounts).enter().append("text").attr("class", "bar-label").attr("x", (d)=>x(d.label) + x.bandwidth() / 2).attr("y", (d)=>y(d.count) - 5).attr("text-anchor", "middle").style("font-size", "10px").text((d)=>d.count);
        // X-axis with ticks (labels) and clickable
        const xAxis = svg.append("g").attr("transform", `translate(0,${height})`).call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["axisBottom"])(x).tickSize(0));
        xAxis.selectAll("text").style("cursor", "pointer").attr("fill", (d)=>{
            const binObj = binCounts.find((b)=>b.label === d);
            return getFill(binObj);
        }).on("click", function(event, label) {
            const binObj = binCounts.find((b)=>b.label === label);
            if (!binObj) return;
            if (selectedBins.includes(binObj.bin)) {
                updateSelectedBins(selectedBins.filter((b)=>b !== binObj.bin));
            } else {
                updateSelectedBins([
                    ...selectedBins,
                    binObj.bin
                ].sort());
            }
        });
        // Remove x-axis line
        xAxis.select("path.domain").attr("stroke", "none");
        // X-axis label below the ticks (reduced gap)
        svg.append("text").attr("x", width / 2).attr("y", height + 25) // Reduced gap
        .attr("text-anchor", "middle").style("font-size", "10px") // Reduced font size
        .style("font-weight", "bold").text("Exam Score Bin");
        // Y-axis label only (no ticks/numbers)
        svg.append("text").attr("transform", `rotate(-90)`).attr("x", -height / 2).attr("y", -15).attr("text-anchor", "middle").style("font-size", "10px") // Reduced font size
        .style("font-weight", "bold").text("Count");
        // Remove y-axis ticks and numbers
        svg.append("g").call((g)=>g.selectAll(".tick").remove()).call((g)=>g.selectAll("path.domain").remove());
        // Title (reduced font size)
        svg.append("text").attr("x", width / 2).attr("y", -30).attr("text-anchor", "middle").style("font-size", "12px") // Reduced font size
        .style("font-weight", "bold").text("Exam Score Distribution");
        // Legend (spaced from bars)
        const legend = svg.append("g").attr("transform", `translate(${width + 20}, 0)`);
        BIN_RANGES.forEach((bin, i)=>{
            legend.append("rect").attr("x", 0).attr("y", i * 22).attr("width", 16).attr("height", 16).attr("fill", bin.color);
            legend.append("text").attr("x", 24).attr("y", i * 22 + 12).attr("font-size", "12px").attr("alignment-baseline", "middle").text(bin.label);
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        ref: svgRef
    }, void 0, false, {
        fileName: "[project]/src/components/histogram.js",
        lineNumber: 164,
        columnNumber: 10
    }, this);
};
_s(Histogram, "89Ty783ABEwsfMbSOeu9vscWF34=");
_c = Histogram;
const __TURBOPACK__default__export__ = Histogram;
var _c;
__turbopack_context__.k.register(_c, "Histogram");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/horizontalBarChart.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-client] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/max.js [app-client] (ecmascript) <export default as max>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-client] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/band.js [app-client] (ecmascript) <export default as scaleBand>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
// Define bin ranges and colors
const BIN_RANGES = [
    {
        bin: 1,
        label: "50–64",
        range: [
            50,
            65
        ],
        color: "#4f46e5"
    },
    {
        bin: 2,
        label: "65–79",
        range: [
            65,
            80
        ],
        color: "#FFD600"
    },
    {
        bin: 3,
        label: "80–89",
        range: [
            80,
            90
        ],
        color: "#00C853"
    },
    {
        bin: 4,
        label: "90–100",
        range: [
            90,
            101
        ],
        color: "#FF1744"
    }
];
// All possible categories for each variable
const ALL_CATEGORIES = {
    Distance_from_Home: [
        "Near",
        "Moderate",
        "Far"
    ],
    Parental_Education_Level: [
        "High School",
        "College",
        "Postgraduate"
    ],
    Teacher_Quality: [
        "Low",
        "Medium",
        "High"
    ],
    Family_Income: [
        "Low",
        "Medium",
        "High"
    ],
    Motivation_Level: [
        "Low",
        "Medium",
        "High"
    ],
    Access_to_Resources: [
        "Low",
        "Medium",
        "High"
    ],
    Parental_Involvement: [
        "Low",
        "Medium",
        "High"
    ],
    Learning_Disabilities: [
        "Yes",
        "No"
    ],
    Peer_Influence: [
        "Positive",
        "Neutral",
        "Negative"
    ],
    Extracurricular_Activities: [
        "Yes",
        "No"
    ]
};
function getBin(score) {
    for (const bin of BIN_RANGES){
        if (score >= bin.range[0] && score < bin.range[1]) return bin;
    }
    return null;
}
const HorizontalBarChart = ({ data, variables, distanceFromHome, updateDistanceFromHome, parentalEducationLevel, updateParentalEducationLevel, teacherQuality, updateTeacherQuality, familyIncome, updateFamilyIncome, motivationLevel, updateMotivationLevel, accessToResources, updateAccessToResources, parentalInvolvement, updateParentalInvolvement, learningDisabilities, updateLearningDisabilities, peerInfluence, updatePeerInfluence, extracurricularActivities, updateExtracurricularActivities, selectedBins })=>{
    _s();
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    // Helper to get state array and updater for a variable
    const getStateAndUpdater = (varName)=>{
        switch(varName){
            case "Distance_from_Home":
                return [
                    distanceFromHome,
                    updateDistanceFromHome
                ];
            case "Parental_Education_Level":
                return [
                    parentalEducationLevel,
                    updateParentalEducationLevel
                ];
            case "Teacher_Quality":
                return [
                    teacherQuality,
                    updateTeacherQuality
                ];
            case "Family_Income":
                return [
                    familyIncome,
                    updateFamilyIncome
                ];
            case "Motivation_Level":
                return [
                    motivationLevel,
                    updateMotivationLevel
                ];
            case "Access_to_Resources":
                return [
                    accessToResources,
                    updateAccessToResources
                ];
            case "Parental_Involvement":
                return [
                    parentalInvolvement,
                    updateParentalInvolvement
                ];
            case "Learning_Disabilities":
                return [
                    learningDisabilities,
                    updateLearningDisabilities
                ];
            case "Peer_Influence":
                return [
                    peerInfluence,
                    updatePeerInfluence
                ];
            case "Extracurricular_Activities":
                return [
                    extracurricularActivities,
                    updateExtracurricularActivities
                ];
            default:
                return [
                    [],
                    ()=>{}
                ];
        }
    };
    // Reset all filters
    const resetAllFilters = ()=>{
        updateDistanceFromHome([]);
        updateParentalEducationLevel([]);
        updateTeacherQuality([]);
        updateFamilyIncome([]);
        updateMotivationLevel([]);
        updateAccessToResources([]);
        updateParentalInvolvement([]);
        updateLearningDisabilities([]);
        updatePeerInfluence([]);
        updateExtracurricularActivities([]);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HorizontalBarChart.useEffect": ()=>{
            if (!data) return;
            // Prepare data for stacked bar chart
            const processedData = variables.map({
                "HorizontalBarChart.useEffect.processedData": (varName)=>{
                    const allCategories = ALL_CATEGORIES[varName] || [];
                    const counts = allCategories.map({
                        "HorizontalBarChart.useEffect.processedData.counts": (cat)=>{
                            const filtered = data.filter({
                                "HorizontalBarChart.useEffect.processedData.counts.filtered": (d)=>d[varName] === cat
                            }["HorizontalBarChart.useEffect.processedData.counts.filtered"]);
                            const binCounts = BIN_RANGES.map({
                                "HorizontalBarChart.useEffect.processedData.counts.binCounts": (bin)=>({
                                        bin: bin.bin,
                                        color: bin.color,
                                        count: filtered.filter({
                                            "HorizontalBarChart.useEffect.processedData.counts.binCounts": (d)=>{
                                                const score = +d.Exam_Score;
                                                return score >= bin.range[0] && score < bin.range[1];
                                            }
                                        }["HorizontalBarChart.useEffect.processedData.counts.binCounts"]).length
                                    })
                            }["HorizontalBarChart.useEffect.processedData.counts.binCounts"]);
                            const total = binCounts.reduce({
                                "HorizontalBarChart.useEffect.processedData.counts.total": (sum, b)=>sum + b.count
                            }["HorizontalBarChart.useEffect.processedData.counts.total"], 0);
                            return {
                                category: cat,
                                binCounts,
                                total
                            };
                        }
                    }["HorizontalBarChart.useEffect.processedData.counts"]);
                    return {
                        varName,
                        counts
                    };
                }
            }["HorizontalBarChart.useEffect.processedData"]);
            drawChart(processedData);
        // eslint-disable-next-line
        }
    }["HorizontalBarChart.useEffect"], [
        data,
        variables,
        distanceFromHome,
        parentalEducationLevel,
        teacherQuality,
        familyIncome,
        motivationLevel,
        accessToResources,
        parentalInvolvement,
        learningDisabilities,
        peerInfluence,
        extracurricularActivities,
        selectedBins
    ]);
    const drawChart = (dataset)=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(ref.current).selectAll("*").remove();
        // Dimensions
        const width = 580, height = 900;
        const margin = {
            top: 60,
            right: 40,
            bottom: 100,
            left: 230
        }; // Increased left margin
        // Create SVG
        const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(ref.current).append('svg').attr('width', width).attr('height', height);
        // Title group for title and button
        const titleGroup = svg.append('g');
        // Title
        titleGroup.append('text').attr('x', width / 2 - 40).attr('y', 35).attr('text-anchor', 'middle').style('font-size', '20px').style('font-weight', 'bold').text('Student Performance Factors Distribution');
        // Reset All button
        const buttonWidth = 90, buttonHeight = 28;
        const buttonX = width / 2 + 170;
        const buttonY = 18;
        const resetButton = titleGroup.append('g').attr('transform', `translate(${buttonX},${buttonY})`).style('cursor', 'pointer').on('click', resetAllFilters);
        resetButton.append('rect').attr('width', buttonWidth).attr('height', buttonHeight).attr('rx', 6).attr('fill', '#f3f4f6').attr('stroke', '#4f46e5').attr('stroke-width', 1.5);
        resetButton.append('text').attr('x', buttonWidth / 2).attr('y', buttonHeight / 2 + 5).attr('text-anchor', 'middle').style('font-size', '14px').style('fill', '#4f46e5').style('font-weight', 'bold').text('Reset All');
        // Max total for scaling
        const maxCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(dataset.flatMap((d)=>d.counts.map((c)=>c.total))) || 1;
        // Scales
        const xScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
            0,
            maxCount
        ]).range([
            margin.left,
            width - margin.right
        ]);
        const yScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(dataset.map((d)=>d.varName)).range([
            height - margin.bottom,
            margin.top
        ]).padding(0.2);
        // Create variable groups
        const variableGroups = svg.selectAll('.variable-group').data(dataset).enter().append('g').attr('transform', (d)=>`translate(0,${yScale(d.varName)})`);
        // Add bars and labels
        variableGroups.each(function(d) {
            const [currentArray, updateArray] = getStateAndUpdater(d.varName);
            const categoryScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(d.counts.map((c)=>c.category)).range([
                0,
                yScale.bandwidth()
            ]).padding(0.05);
            const group = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this);
            // Stacked bars
            group.selectAll('g.category').data(d.counts).enter().append('g').attr('class', 'category').attr('transform', (c)=>`translate(0,${categoryScale(c.category)})`).each(function(c) {
                let x0 = margin.left;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).selectAll('rect').data(c.binCounts).enter().append('rect').attr('x', (bin, i)=>{
                    const prevWidth = c.binCounts.slice(0, i).reduce((sum, b)=>sum + (xScale(b.count) - xScale(0)), 0);
                    return x0 + prevWidth;
                }).attr('y', 0).attr('width', (bin)=>Math.max(0, xScale(bin.count) - xScale(0))).attr('height', categoryScale.bandwidth() * 0.95).attr('fill', (bin)=>currentArray.length === 0 || currentArray.includes(c.category) ? bin.color : '#ccc').attr('rx', 4).style('cursor', 'pointer').on('click', function(event) {
                    event.stopPropagation();
                    if (currentArray.includes(c.category)) {
                        updateArray(currentArray.filter((val)=>val !== c.category));
                    } else {
                        updateArray([
                            ...currentArray,
                            c.category
                        ]);
                    }
                });
            });
            // Total count labels (top of stacked bar)
            group.selectAll('.total-label').data(d.counts).enter().append('text').attr('class', 'total-label').attr('x', (c)=>margin.left + c.binCounts.reduce((sum, b)=>sum + (xScale(b.count) - xScale(0)), 0) + 12).attr('y', (c)=>categoryScale(c.category) + 11).attr('text-anchor', 'start').style('font-size', '0.7em').style('fill', 'black').text((c)=>c.total);
            // Category labels (right side, more spacing)
            group.selectAll('.category-label').data(d.counts).enter().append('text').attr('class', 'category-label').attr('x', (c)=>margin.left - 22) // More space between category and variable labels
            .attr('y', (c)=>categoryScale(c.category) + categoryScale.bandwidth() / 2).attr('dy', '0.35em').attr('text-anchor', 'end').style('font-size', '0.7em').style('fill', 'black').text((c)=>c.category);
        });
        // Variable labels (multi-line, clickable to reset, moved further left)
        variableGroups.append('text').attr('x', margin.left - 80) // Move further left
        .attr('y', yScale.bandwidth() / 2 - 5).attr('text-anchor', 'end').attr('dominant-baseline', 'middle').style('font-size', '0.95em').style('cursor', 'pointer').style('font-weight', 'bold').on('click', function(event, d) {
            event.stopPropagation();
            const [, updateArray] = getStateAndUpdater(d.varName);
            updateArray([]); // Reset filter
        }).selectAll('tspan').data((d)=>d.varName.split('_')).enter().append('tspan').attr('x', margin.left - 80).attr('dy', (d, i)=>i === 0 ? 0 : '0.9em').text((d)=>d.charAt(0).toUpperCase() + d.slice(1).toLowerCase());
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref
    }, void 0, false, {
        fileName: "[project]/src/components/horizontalBarChart.js",
        lineNumber: 277,
        columnNumber: 10
    }, this);
};
_s(HorizontalBarChart, "8uVE59eA/r6b92xF80p7sH8rXLk=");
_c = HorizontalBarChart;
const __TURBOPACK__default__export__ = HorizontalBarChart;
var _c;
__turbopack_context__.k.register(_c, "HorizontalBarChart");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/gender.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$group$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/group.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-client] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-client] (ecmascript) <export default as scaleLinear>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const GenderDistribution = ({ data, gender, updateGender, width = 150, height = 200 })=>{
    _s();
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    // Click handlers (unchanged)
    const handleMaleClick = (event)=>{
        event.preventDefault();
        event.stopPropagation();
        if (gender.includes("Male")) {
            updateGender(gender.filter((g)=>g !== "Male"));
        } else {
            updateGender([
                ...gender,
                "Male"
            ]);
        }
    };
    const handleFemaleClick = (event)=>{
        event.preventDefault();
        event.stopPropagation();
        if (gender.includes("Female")) {
            updateGender(gender.filter((g)=>g !== "Female"));
        } else {
            updateGender([
                ...gender,
                "Female"
            ]);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GenderDistribution.useEffect": ()=>{
            if (!data || !data.length) return;
            const genderCounts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$group$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rollup"])(data, {
                "GenderDistribution.useEffect.genderCounts": (v)=>v.length
            }["GenderDistribution.useEffect.genderCounts"], {
                "GenderDistribution.useEffect.genderCounts": (d)=>d.Gender
            }["GenderDistribution.useEffect.genderCounts"]);
            const maleCount = genderCounts.get("Male") || 0;
            const femaleCount = genderCounts.get("Female") || 0;
            const total = maleCount + femaleCount;
            const malePct = total ? Math.round(maleCount / total * 100) : 0;
            const femalePct = total ? Math.round(femaleCount / total * 100) : 0;
            drawSvg(malePct, femalePct);
        // eslint-disable-next-line
        }
    }["GenderDistribution.useEffect"], [
        data,
        gender,
        width,
        height
    ]);
    function drawSvg(malePct, femalePct) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).selectAll("*").remove();
        // --- ADJUSTMENTS BEGIN HERE ---
        // 1. Reduce total height by 10%
        const adjustedHeight = height * 0.9;
        // 2. Add a larger gap between title and head
        const titlePad = 28; // was 20
        // 3. Adjust figure height accordingly
        const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).append("svg").attr("width", width).attr("height", adjustedHeight);
        // Title
        svg.append("text").attr("x", width / 2).attr("y", titlePad - 5) // This keeps a gap between title and head
        .attr("text-anchor", "middle").attr("font-size", 0.08 * width).attr("font-weight", "bold").text("Gender Distribution");
        // Scales for figure (adjusted for new height)
        const figX = 0.12 * width;
        const figY = titlePad;
        const figWidth = width * 0.75 * 0.9;
        // 4. Reduce body height slightly (reduce figHeight a bit more)
        const figHeight = adjustedHeight - titlePad - 16; // was -10
        const scaleX = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
            0,
            64
        ]).range([
            figX,
            figX + figWidth
        ]);
        const scaleY = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
            0,
            128
        ]).range([
            figY,
            figY + figHeight
        ]);
        // --- CLIP PATHS (unchanged) ---
        const defs = svg.append("defs");
        defs.append("clipPath").attr("id", "maleClip").append("rect").attr("x", scaleX(0)).attr("y", scaleY(128 - 128 * malePct / 100)).attr("width", scaleX(32) - scaleX(0)).attr("height", scaleY(128 * malePct / 100) - scaleY(0));
        defs.append("clipPath").attr("id", "femaleClip").append("rect").attr("x", scaleX(32)).attr("y", scaleY(128 - 128 * femalePct / 100)).attr("width", scaleX(64) - scaleX(32)).attr("height", scaleY(128 * femalePct / 100) - scaleY(0));
        // Main color logic (unchanged)
        const maleFill = gender.length === 0 || gender.includes("Male") ? "deepskyblue" : "#ccc";
        const femaleFill = gender.length === 0 || gender.includes("Female") ? "hotpink" : "#ccc";
        // --- FIGURE FILLS ---
        // 5. Reduce head radius and keep centered
        const headRadius = scaleX(40) - scaleX(32); // was scaleX(44) - scaleX(32)
        svg.append("circle").attr("cx", scaleX(32)).attr("cy", scaleY(16)).attr("r", headRadius * 0.75).attr("fill", maleFill).attr("clip-path", "url(#maleClip)");
        svg.append("circle").attr("cx", scaleX(32)).attr("cy", scaleY(16)).attr("r", headRadius * 0.75).attr("fill", femaleFill).attr("clip-path", "url(#femaleClip)");
        // --- BODY PATHS (unchanged, but will be slightly smaller due to figHeight) ---
        svg.append("path").attr("d", `
        M${scaleX(20)} ${scaleY(28)} L${scaleX(20)} ${scaleY(128)} L${scaleX(24)} ${scaleY(128)} L${scaleX(28)} ${scaleY(60)} L${scaleX(28)} ${scaleY(28)} Z
      `).attr("fill", maleFill).attr("clip-path", "url(#maleClip)");
        svg.append("path").attr("d", `
        M${scaleX(14)} ${scaleY(40)} Q${scaleX(12)} ${scaleY(50)}, ${scaleX(14)} ${scaleY(70)}
        L${scaleX(18)} ${scaleY(70)} Q${scaleX(16)} ${scaleY(50)}, ${scaleX(18)} ${scaleY(40)} Z
      `).attr("fill", maleFill).attr("clip-path", "url(#maleClip)");
        svg.append("path").attr("d", `
        M${scaleX(32)} ${scaleY(28)} L${scaleX(36)} ${scaleY(40)} L${scaleX(48)} ${scaleY(80)} L${scaleX(36)} ${scaleY(80)}
        L${scaleX(40)} ${scaleY(128)} L${scaleX(34)} ${scaleY(128)} L${scaleX(32)} ${scaleY(80)} L${scaleX(32)} ${scaleY(60)} Z
      `).attr("fill", femaleFill).attr("clip-path", "url(#femaleClip)");
        svg.append("path").attr("d", `
        M${scaleX(50)} ${scaleY(40)} Q${scaleX(52)} ${scaleY(50)}, ${scaleX(50)} ${scaleY(70)}
        L${scaleX(46)} ${scaleY(70)} Q${scaleX(48)} ${scaleY(50)}, ${scaleX(46)} ${scaleY(40)} Z
      `).attr("fill", femaleFill).attr("clip-path", "url(#femaleClip)");
        svg.append("path").attr("d", `
        M${scaleX(32)} ${scaleY(60)} L${scaleX(32)} ${scaleY(80)} L${scaleX(34)} ${scaleY(80)}
        L${scaleX(34)} ${scaleY(128)} L${scaleX(40)} ${scaleY(128)} L${scaleX(40)} ${scaleY(80)} L${scaleX(48)} ${scaleY(80)} Z
      `).attr("fill", femaleFill).attr("clip-path", "url(#femaleClip)");
        // --- OUTLINE (unchanged, but use new headRadius) ---
        svg.append("circle").attr("cx", scaleX(32)).attr("cy", scaleY(16)).attr("r", headRadius * 0.75).attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        svg.append("path").attr("d", `
        M${scaleX(20)} ${scaleY(28)} L${scaleX(20)} ${scaleY(128)} L${scaleX(24)} ${scaleY(128)} L${scaleX(28)} ${scaleY(60)} L${scaleX(28)} ${scaleY(28)} Z
      `).attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        svg.append("path").attr("d", `
        M${scaleX(14)} ${scaleY(40)} Q${scaleX(12)} ${scaleY(50)}, ${scaleX(14)} ${scaleY(70)}
        L${scaleX(18)} ${scaleY(70)} Q${scaleX(16)} ${scaleY(50)}, ${scaleX(18)} ${scaleY(40)} Z
      `).attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        svg.append("path").attr("d", `
        M${scaleX(32)} ${scaleY(28)} L${scaleX(36)} ${scaleY(40)} L${scaleX(48)} ${scaleY(80)} L${scaleX(36)} ${scaleY(80)}
        L${scaleX(40)} ${scaleY(128)} L${scaleX(34)} ${scaleY(128)} L${scaleX(32)} ${scaleY(80)} L${scaleX(32)} ${scaleY(60)} Z
      `).attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        svg.append("path").attr("d", `
        M${scaleX(50)} ${scaleY(40)} Q${scaleX(52)} ${scaleY(50)}, ${scaleX(50)} ${scaleY(70)}
        L${scaleX(46)} ${scaleY(70)} Q${scaleX(48)} ${scaleY(50)}, ${scaleX(46)} ${scaleY(40)} Z
      `).attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        svg.append("path").attr("d", `
        M${scaleX(32)} ${scaleY(60)} L${scaleX(32)} ${scaleY(80)} L${scaleX(34)} ${scaleY(80)}
        L${scaleX(34)} ${scaleY(128)} L${scaleX(40)} ${scaleY(128)} L${scaleX(40)} ${scaleY(80)} L${scaleX(48)} ${scaleY(80)} Z
      `).attr("fill", "none").attr("stroke", "black").attr("stroke-width", 2);
        // --- PERCENTAGE LABELS (unchanged) ---
        svg.append("text").attr("x", scaleX(6) - 5).attr("y", scaleY(70)).attr("text-anchor", "middle").attr("font-size", "12px").attr("fill", maleFill).attr("font-weight", "bold").text(`${malePct}%`);
        svg.append("text").attr("x", scaleX(58) + 5).attr("y", scaleY(70)).attr("text-anchor", "middle").attr("font-size", "12px").attr("fill", femaleFill).attr("font-weight", "bold").text(`${femalePct}%`);
        // Male side clickable area (unchanged)
        svg.append("rect").attr("x", scaleX(0)).attr("y", scaleY(0)).attr("width", scaleX(32) - scaleX(0)).attr("height", scaleY(128) - scaleY(0)).attr("fill", "transparent").style("cursor", "pointer").on("click", handleMaleClick).on("mouseover", function() {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).attr("fill", "rgba(0,0,0,0.05)");
        }).on("mouseout", function() {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).attr("fill", "transparent");
        });
        // Female side clickable area (unchanged)
        svg.append("rect").attr("x", scaleX(32)).attr("y", scaleY(0)).attr("width", scaleX(64) - scaleX(32)).attr("height", scaleY(128) - scaleY(0)).attr("fill", "transparent").style("cursor", "pointer").on("click", handleFemaleClick).on("mouseover", function() {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).attr("fill", "rgba(0,0,0,0.05)");
        }).on("mouseout", function() {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).attr("fill", "transparent");
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: svgRef
    }, void 0, false, {
        fileName: "[project]/src/components/gender.js",
        lineNumber: 328,
        columnNumber: 10
    }, this);
};
_s(GenderDistribution, "89Ty783ABEwsfMbSOeu9vscWF34=");
_c = GenderDistribution;
const __TURBOPACK__default__export__ = GenderDistribution;
var _c;
__turbopack_context__.k.register(_c, "GenderDistribution");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/PCPPlot.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-client] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__point__as__scalePoint$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/band.js [app-client] (ecmascript) <export point as scalePoint>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-client] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$extent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__extent$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/extent.js [app-client] (ecmascript) <export default as extent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$ordinal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleOrdinal$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/ordinal.js [app-client] (ecmascript) <export default as scaleOrdinal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2d$chromatic$2f$src$2f$categorical$2f$category10$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__schemeCategory10$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale-chromatic/src/categorical/category10.js [app-client] (ecmascript) <export default as schemeCategory10>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/line.js [app-client] (ecmascript) <export default as line>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-axis/src/axis.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const PCPPlot = ({ data, order, setOrder })=>{
    _s();
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    //const k = 4; // Default value as instructed
    // Changed dependency to queryParameter
    // Function to move a dimension left in the order array
    const moveAxisLeft = (dimension)=>{
        const currentIndex = order.indexOf(dimension);
        if (currentIndex <= 0) return; // Can't move left if already leftmost
        const newOrder = [
            ...order
        ];
        // Swap with the dimension to the left
        [newOrder[currentIndex], newOrder[currentIndex - 1]] = [
            newOrder[currentIndex - 1],
            newOrder[currentIndex]
        ];
        setOrder(newOrder);
    };
    // Function to move a dimension right in the order array
    const moveAxisRight = (dimension)=>{
        const currentIndex = order.indexOf(dimension);
        if (currentIndex >= order.length - 1) return; // Can't move right if already rightmost
        const newOrder = [
            ...order
        ];
        // Swap with the dimension to the right
        [newOrder[currentIndex], newOrder[currentIndex + 1]] = [
            newOrder[currentIndex + 1],
            newOrder[currentIndex]
        ];
        setOrder(newOrder);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PCPPlot.useEffect": ()=>{
            if (data.length === 0 || !order) return;
            const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current);
            svg.selectAll("*").remove();
            const margin = {
                top: 80,
                right: 30,
                bottom: 100,
                left: 10
            }, width = 1450 - margin.left - margin.right, height = 400 - margin.top - margin.bottom;
            const dimensions = [
                ...order
            ];
            const x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__point__as__scalePoint$3e$__["scalePoint"])().domain(dimensions).range([
                0,
                width
            ]).padding(1.5);
            const y = {};
            dimensions.forEach({
                "PCPPlot.useEffect": (dim)=>{
                    if (typeof data[0][dim] === "number") {
                        y[dim] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$extent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__extent$3e$__["extent"])(data, {
                            "PCPPlot.useEffect": (d)=>+d[dim]
                        }["PCPPlot.useEffect"])).range([
                            height,
                            0
                        ]);
                    } else {
                        y[dim] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__point__as__scalePoint$3e$__["scalePoint"])().domain([
                            ...new Set(data.map({
                                "PCPPlot.useEffect": (d)=>d[dim]
                            }["PCPPlot.useEffect"]))
                        ]).range([
                            height,
                            0
                        ]);
                    }
                }
            }["PCPPlot.useEffect"]);
            const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$ordinal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleOrdinal$3e$__["scaleOrdinal"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2d$chromatic$2f$src$2f$categorical$2f$category10$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__schemeCategory10$3e$__["schemeCategory10"]);
            const line = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__["line"])().x({
                "PCPPlot.useEffect.line": (d)=>x(d.dimension)
            }["PCPPlot.useEffect.line"]).y({
                "PCPPlot.useEffect.line": (d)=>y[d.dimension](d.value)
            }["PCPPlot.useEffect.line"]);
            const g = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);
            svg.append("text").attr("x", width / 2).attr("y", 30).attr("text-anchor", "middle").style("font-size", "24px").style("font-weight", "bold").text("PCP Plot");
            g.selectAll(".line").data(data).enter().append("path").attr("d", {
                "PCPPlot.useEffect": (d)=>line(dimensions.map({
                        "PCPPlot.useEffect": (dim)=>({
                                dimension: dim,
                                value: d[dim]
                            })
                    }["PCPPlot.useEffect"]))
            }["PCPPlot.useEffect"]).style("fill", "none").style("stroke", {
                "PCPPlot.useEffect": (d)=>color(d.bin_id)
            }["PCPPlot.useEffect"]).style("opacity", 0.7);
            const axisGroups = g.selectAll(".axis").data(dimensions).enter().append("g").attr("class", "axis").attr("transform", {
                "PCPPlot.useEffect.axisGroups": (d)=>`translate(${x(d)},0)`
            }["PCPPlot.useEffect.axisGroups"]).each({
                "PCPPlot.useEffect.axisGroups": function(d) {
                    const axisGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this);
                    axisGroup.call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["axisLeft"])(y[d]).tickSize(6).tickPadding(10));
                    axisGroup.selectAll(".tick text").style("font-weight", "bold").each({
                        "PCPPlot.useEffect.axisGroups": function() {
                            const text = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this);
                            const words = text.text();
                            text.text("");
                            for(let i = 0; i < words.length; i += 14){
                                text.append("tspan").attr("x", 0).attr("dy", i === 0 ? "0em" : "1.2em").text(words.slice(i, i + 14));
                            }
                        }
                    }["PCPPlot.useEffect.axisGroups"]);
                }
            }["PCPPlot.useEffect.axisGroups"]);
            g.selectAll(".axis line, .axis path").style("stroke", "black");
            // Add axis labels and reordering buttons
            const axisLabels = g.selectAll(".axis-label-container").data(dimensions).enter().append("g").attr("class", "axis-label-container").attr("transform", {
                "PCPPlot.useEffect.axisLabels": (d)=>`translate(${x(d)},${height + 30})`
            }["PCPPlot.useEffect.axisLabels"]);
            // Add text labels
            axisLabels.append("text").attr("text-anchor", "middle").style("fill", "black").style("font-size", "14px").each({
                "PCPPlot.useEffect": function(d) {
                    if (d.length > 10) {
                        const mid = Math.ceil(d.length / 2);
                        const firstPart = d.slice(0, mid);
                        const secondPart = d.slice(mid);
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).append("tspan").attr("x", 0).attr("dy", "0em").text(firstPart);
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).append("tspan").attr("x", 0).attr("dy", "1.2em").text(secondPart);
                    } else {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).text(d);
                    }
                }
            }["PCPPlot.useEffect"]);
            // Add left button for axis reordering
            axisLabels.append("rect").attr("class", "move-button left").attr("x", -30).attr("y", 25).attr("width", 20).attr("height", 20).attr("rx", 3).attr("fill", {
                "PCPPlot.useEffect": (d)=>order.indexOf(d) > 0 ? "steelblue" : "#ccc"
            }["PCPPlot.useEffect"]).style("cursor", {
                "PCPPlot.useEffect": (d)=>order.indexOf(d) > 0 ? "pointer" : "default"
            }["PCPPlot.useEffect"]).on("click", {
                "PCPPlot.useEffect": function(event, d) {
                    if (order.indexOf(d) > 0) {
                        event.stopPropagation();
                        moveAxisLeft(d);
                    }
                }
            }["PCPPlot.useEffect"]);
            // Add left button arrow - Changed fill to white for better contrast
            axisLabels.append("text").attr("class", "move-button-text left").attr("x", -20).attr("y", 40).attr("text-anchor", "middle").attr("fill", "white") // Changed from black to white
            .text("←").style("font-size", "14px").style("font-weight", "bold").style("pointer-events", "none"); // Make text non-interactive
            // Add right button for axis reordering
            axisLabels.append("rect").attr("class", "move-button right").attr("x", 10).attr("y", 25).attr("width", 20).attr("height", 20).attr("rx", 3).attr("fill", {
                "PCPPlot.useEffect": (d)=>order.indexOf(d) < order.length - 1 ? "steelblue" : "#ccc"
            }["PCPPlot.useEffect"]).style("cursor", {
                "PCPPlot.useEffect": (d)=>order.indexOf(d) < order.length - 1 ? "pointer" : "default"
            }["PCPPlot.useEffect"]).on("click", {
                "PCPPlot.useEffect": function(event, d) {
                    if (order.indexOf(d) < order.length - 1) {
                        event.stopPropagation();
                        moveAxisRight(d);
                    }
                }
            }["PCPPlot.useEffect"]);
            // Add right button arrow - Changed fill to white for better contrast
            axisLabels.append("text").attr("class", "move-button-text right").attr("x", 20).attr("y", 40).attr("text-anchor", "middle").attr("fill", "white") // Changed from black to white
            .text("→").style("font-size", "14px").style("font-weight", "bold").style("pointer-events", "none"); // Make text non-interactive
            // Add the legend
            const legend = svg.append("g").attr("transform", `translate(${width - 70}, 10)`);
            const uniqueClusters = [
                ...new Set(data.map({
                    "PCPPlot.useEffect": (d)=>d.bin_id
                }["PCPPlot.useEffect"]))
            ];
            uniqueClusters.forEach({
                "PCPPlot.useEffect": (cluster, i)=>{
                    legend.append("circle").attr("cx", 0).attr("cy", i * 20).attr("r", 5).attr("fill", color(cluster));
                    legend.append("text").attr("x", 10).attr("y", i * 20 + 4).text("cluster " + cluster).style("font-size", "12px").attr("alignment-baseline", "middle");
                }
            }["PCPPlot.useEffect"]);
        }
    }["PCPPlot.useEffect"], [
        data,
        order,
        setOrder
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            textAlign: "center"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            ref: svgRef,
            width: 1500,
            height: 600
        }, void 0, false, {
            fileName: "[project]/src/components/PCPPlot.js",
            lineNumber: 232,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/PCPPlot.js",
        lineNumber: 231,
        columnNumber: 5
    }, this);
};
_s(PCPPlot, "89Ty783ABEwsfMbSOeu9vscWF34=");
_c = PCPPlot;
const __TURBOPACK__default__export__ = PCPPlot;
var _c;
__turbopack_context__.k.register(_c, "PCPPlot");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/linePlot.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$mean$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__mean$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/mean.js [app-client] (ecmascript) <export default as mean>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$deviation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__deviation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/deviation.js [app-client] (ecmascript) <export default as deviation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-client] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/band.js [app-client] (ecmascript) <export default as scaleBand>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-client] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/max.js [app-client] (ecmascript) <export default as max>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-axis/src/axis.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const StatsBarPlot = ({ data })=>{
    _s();
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StatsBarPlot.useEffect": ()=>{
            if (!data.length) return;
            // Calculate statistics
            const avgExam = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$mean$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__mean$3e$__["mean"])(data, {
                "StatsBarPlot.useEffect.avgExam": (d)=>+d.Exam_Score
            }["StatsBarPlot.useEffect.avgExam"]);
            const avgPrev = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$mean$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__mean$3e$__["mean"])(data, {
                "StatsBarPlot.useEffect.avgPrev": (d)=>+d.Previous_Scores
            }["StatsBarPlot.useEffect.avgPrev"]);
            const diffs = data.map({
                "StatsBarPlot.useEffect.diffs": (d)=>+d.Exam_Score - +d.Previous_Scores
            }["StatsBarPlot.useEffect.diffs"]);
            const stdDev = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$deviation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__deviation$3e$__["deviation"])(diffs);
            const barsData = [
                {
                    label: "Average Previous Score",
                    value: avgPrev
                },
                {
                    label: "Average Exam Score",
                    value: avgExam
                },
                {
                    label: "Standard Deviation",
                    value: stdDev
                }
            ];
            // Adjusted margin and width for shorter bars
            const margin = {
                top: 50,
                right: 120,
                bottom: 70,
                left: 40
            };
            const width = 400 - margin.left - margin.right;
            const height = (200 - margin.top - margin.bottom) * 0.9;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).selectAll("*").remove();
            const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).attr("width", width + margin.left + margin.right).attr("height", height + margin.top + margin.bottom).append("g").attr("transform", `translate(${margin.left},${margin.top})`);
            // Make bars shorter and closer together
            const barAreaWidth = width * 0.8; // Only use 60% of width for bars
            const x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(barsData.map({
                "StatsBarPlot.useEffect.x": (d)=>d.label
            }["StatsBarPlot.useEffect.x"])).range([
                0,
                barAreaWidth
            ]).padding(0.30); // Reduced padding for closer bars
            const y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
                0,
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(barsData, {
                    "StatsBarPlot.useEffect.y": (d)=>d.value
                }["StatsBarPlot.useEffect.y"]) * 1.2
            ]).range([
                height,
                0
            ]);
            // Draw bars
            svg.selectAll(".bar").data(barsData).enter().append("rect").attr("class", "bar").attr("x", {
                "StatsBarPlot.useEffect": (d)=>x(d.label)
            }["StatsBarPlot.useEffect"]).attr("y", {
                "StatsBarPlot.useEffect": (d)=>y(d.value)
            }["StatsBarPlot.useEffect"]).attr("width", x.bandwidth()).attr("height", {
                "StatsBarPlot.useEffect": (d)=>height - y(d.value)
            }["StatsBarPlot.useEffect"]).attr("fill", {
                "StatsBarPlot.useEffect": (d)=>{
                    if (d.label.includes("Previous")) return "steelblue";
                    if (d.label.includes("Exam")) return "hotpink";
                    return "gray";
                }
            }["StatsBarPlot.useEffect"]);
            // Add value labels
            svg.selectAll(".value-label").data(barsData).enter().append("text").attr("class", "value-label").attr("x", {
                "StatsBarPlot.useEffect": (d)=>x(d.label) + x.bandwidth() / 2
            }["StatsBarPlot.useEffect"]).attr("y", {
                "StatsBarPlot.useEffect": (d)=>y(d.value) - 5
            }["StatsBarPlot.useEffect"]).attr("text-anchor", "middle").style("font-size", "10.5px").style("font-weight", "bold").text({
                "StatsBarPlot.useEffect": (d)=>d.value !== undefined && !isNaN(d.value) ? d.value.toFixed(1) : "N/A"
            }["StatsBarPlot.useEffect"]);
            // Axes
            const xAxis = svg.append("g").attr("transform", `translate(0,${height})`).call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["axisBottom"])(x));
            xAxis.selectAll("text").each({
                "StatsBarPlot.useEffect": function(d) {
                    const words = d.split(" ");
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).text(null) // Clear existing label
                    .selectAll("tspan").data(words).enter().append("tspan").attr("x", 0).attr("dy", {
                        "StatsBarPlot.useEffect": (word, i)=>i === 0 ? "1em" : "1.2em"
                    }["StatsBarPlot.useEffect"]).text({
                        "StatsBarPlot.useEffect": (word)=>word
                    }["StatsBarPlot.useEffect"]);
                }
            }["StatsBarPlot.useEffect"]).attr("text-anchor", "middle").attr("dx", "0em").attr("dy", "1.5em");
            svg.append("g").call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["axisLeft"])(y));
            // Title
            svg.append("text").attr("x", barAreaWidth / 2).attr("y", -25).attr("text-anchor", "middle").style("font-size", "13px").style("font-weight", "bold").text("Score Statistics");
            // Legend (to the right of the bars)
            const legendX = barAreaWidth + 30;
            const legend = svg.append("g").attr("font-size", 12);
            legend.append("rect").attr("x", legendX - 42).attr("y", -20).attr("width", 15).attr("height", 15).attr("fill", "steelblue");
            legend.append("text").attr("x", legendX - 20).attr("y", -8).text("Avg Prev Scores");
            legend.append("rect").attr("x", legendX - 42).attr("y", 0).attr("width", 15).attr("height", 15).attr("fill", "hotpink");
            legend.append("text").attr("x", legendX - 20).attr("y", 12).text("Avg Exam Scores");
            legend.append("rect").attr("x", legendX - 42).attr("y", 20).attr("width", 15).attr("height", 15).attr("fill", "gray");
            legend.append("text").attr("x", legendX - 20).attr("y", 32).text("Standard Deviation");
        }
    }["StatsBarPlot.useEffect"], [
        data
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            textAlign: "center",
            color: "black"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            ref: svgRef
        }, void 0, false, {
            fileName: "[project]/src/components/linePlot.js",
            lineNumber: 167,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/linePlot.js",
        lineNumber: 166,
        columnNumber: 5
    }, this);
};
_s(StatsBarPlot, "89Ty783ABEwsfMbSOeu9vscWF34=");
_c = StatsBarPlot;
const __TURBOPACK__default__export__ = StatsBarPlot;
var _c;
__turbopack_context__.k.register(_c, "StatsBarPlot");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/scatterPlot.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-client] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-client] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/min.js [app-client] (ecmascript) <export default as min>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/max.js [app-client] (ecmascript) <export default as max>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$brush$2f$src$2f$brush$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__brush$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-brush/src/brush.js [app-client] (ecmascript) <export default as brush>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-axis/src/axis.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const ScatterPlotMatrix = ({ numericFeatures, data, onBrush })=>{
    _s();
    const [xIndex, setXIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [yIndex, setYIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    // Navigation handlers
    const moveXLeft = ()=>setXIndex((prev)=>prev > 0 ? prev - 1 : numericFeatures.length - 1);
    const moveXRight = ()=>setXIndex((prev)=>prev < numericFeatures.length - 1 ? prev + 1 : 0);
    const moveYLeft = ()=>setYIndex((prev)=>prev > 0 ? prev - 1 : numericFeatures.length - 1);
    const moveYRight = ()=>setYIndex((prev)=>prev < numericFeatures.length - 1 ? prev + 1 : 0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ScatterPlotMatrix.useEffect": ()=>{
            if (!data.length || !numericFeatures) return;
            const xFeature = numericFeatures[xIndex];
            const yFeature = numericFeatures[yIndex];
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).selectAll("*").remove();
            const binColors = {
                1: "#4f46e5",
                2: "#FFD600",
                3: "#00C853",
                4: "#FF1744" // red
            };
            const margin = {
                top: 50,
                right: 50,
                bottom: 50,
                left: 60
            };
            const width = 380 - margin.left - margin.right;
            const height = 240 - margin.top - margin.bottom;
            const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).attr('width', width + margin.left + margin.right).attr('height', height + margin.top + margin.bottom).append('g').attr('transform', `translate(${margin.left},${margin.top})`);
            const x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__["min"])(data, {
                    "ScatterPlotMatrix.useEffect.x": (d)=>+d[xFeature]
                }["ScatterPlotMatrix.useEffect.x"]) * 0.9,
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(data, {
                    "ScatterPlotMatrix.useEffect.x": (d)=>+d[xFeature]
                }["ScatterPlotMatrix.useEffect.x"]) * 1.1
            ]).range([
                0,
                width
            ]);
            const y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__["min"])(data, {
                    "ScatterPlotMatrix.useEffect.y": (d)=>+d[yFeature]
                }["ScatterPlotMatrix.useEffect.y"]) * 0.9,
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(data, {
                    "ScatterPlotMatrix.useEffect.y": (d)=>+d[yFeature]
                }["ScatterPlotMatrix.useEffect.y"]) * 1.1
            ]).range([
                height,
                0
            ]);
            // Brushing
            const brush = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$brush$2f$src$2f$brush$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__brush$3e$__["brush"])().extent([
                [
                    0,
                    0
                ],
                [
                    width,
                    height
                ]
            ]).on('end', {
                "ScatterPlotMatrix.useEffect.brush": (event)=>{
                    if (!event.selection) {
                        onBrush([]);
                        return;
                    }
                    const [[x0, y0], [x1, y1]] = event.selection;
                    const selectedPoints = data.filter({
                        "ScatterPlotMatrix.useEffect.brush.selectedPoints": (d)=>{
                            const cx = x(+d[xFeature]);
                            const cy = y(+d[yFeature]);
                            return cx >= x0 && cx <= x1 && cy >= y0 && cy <= y1;
                        }
                    }["ScatterPlotMatrix.useEffect.brush.selectedPoints"]);
                    onBrush(selectedPoints.map({
                        "ScatterPlotMatrix.useEffect.brush": (d)=>d.id
                    }["ScatterPlotMatrix.useEffect.brush"]));
                }
            }["ScatterPlotMatrix.useEffect.brush"]);
            svg.append("g").attr("class", "brush").call(brush);
            // Points
            svg.selectAll('circle').data(data).enter().append('circle').attr('cx', {
                "ScatterPlotMatrix.useEffect": (d)=>x(+d[xFeature])
            }["ScatterPlotMatrix.useEffect"]).attr('cy', {
                "ScatterPlotMatrix.useEffect": (d)=>y(+d[yFeature])
            }["ScatterPlotMatrix.useEffect"]).attr('r', 4).style('fill', {
                "ScatterPlotMatrix.useEffect": (d)=>binColors[d.bin_id] || '#bbb'
            }["ScatterPlotMatrix.useEffect"]).style('opacity', 0.7);
            // X axis
            svg.append('g').attr('transform', `translate(0,${height})`).call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["axisBottom"])(x));
            // Y axis
            svg.append('g').call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["axisLeft"])(y));
            // X axis navigation
            const xAxisLabel = svg.append('g').attr('transform', `translate(${width / 2}, ${height + 40})`);
            xAxisLabel.append('rect').attr('x', -85).attr('y', -15).attr('width', 20).attr('height', 20).attr('rx', 3).attr('fill', 'steelblue').style('cursor', 'pointer').on('click', moveXLeft);
            xAxisLabel.append('text').attr('x', -75).attr('y', 0).attr('text-anchor', 'middle').attr('fill', 'white').style('pointer-events', 'none').text('←');
            xAxisLabel.append('text').attr('x', 0).attr('y', 0).attr('text-anchor', 'middle').style('font-weight', 'bold').text(xFeature);
            xAxisLabel.append('rect').attr('x', 65).attr('y', -15).attr('width', 20).attr('height', 20).attr('rx', 3).attr('fill', 'steelblue').style('cursor', 'pointer').on('click', moveXRight);
            xAxisLabel.append('text').attr('x', 75).attr('y', 0).attr('text-anchor', 'middle').attr('fill', 'white').style('pointer-events', 'none').text('→');
            // Y axis navigation
            const yAxisLabel = svg.append('g').attr('transform', `translate(${-40}, ${height / 2}) rotate(-90)`);
            yAxisLabel.append('rect').attr('x', -85).attr('y', -15).attr('width', 20).attr('height', 20).attr('rx', 3).attr('fill', 'steelblue').style('cursor', 'pointer').on('click', moveYLeft);
            yAxisLabel.append('text').attr('x', -75).attr('y', 0).attr('text-anchor', 'middle').attr('fill', 'white').style('pointer-events', 'none').text('←');
            yAxisLabel.append('text').attr('x', 0).attr('y', 0).attr('text-anchor', 'middle').style('font-weight', 'bold').text(yFeature);
            yAxisLabel.append('rect').attr('x', 65).attr('y', -15).attr('width', 20).attr('height', 20).attr('rx', 3).attr('fill', 'steelblue').style('cursor', 'pointer').on('click', moveYRight);
            yAxisLabel.append('text').attr('x', 75).attr('y', 0).attr('text-anchor', 'middle').attr('fill', 'white').style('pointer-events', 'none').text('→');
            // Title
            svg.append('text').attr('x', width / 2).attr('y', -25).attr('text-anchor', 'middle').style('font-size', '16px').style('font-weight', 'bold').text(`${yFeature} vs ${xFeature}`);
        }
    }["ScatterPlotMatrix.useEffect"], [
        data,
        xIndex,
        yIndex,
        numericFeatures,
        onBrush
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col items-center",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            ref: svgRef,
            width: 380,
            height: 240
        }, void 0, false, {
            fileName: "[project]/src/components/scatterPlot.js",
            lineNumber: 141,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/scatterPlot.js",
        lineNumber: 140,
        columnNumber: 5
    }, this);
};
_s(ScatterPlotMatrix, "psAzQupM+MAval2KIyVMyhurTtg=");
_c = ScatterPlotMatrix;
const __TURBOPACK__default__export__ = ScatterPlotMatrix;
var _c;
__turbopack_context__.k.register(_c, "ScatterPlotMatrix");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/radarPlot.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-client] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$mean$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__mean$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/mean.js [app-client] (ecmascript) <export default as mean>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-client] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/line.js [app-client] (ecmascript) <export default as line>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$curve$2f$linearClosed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__curveLinearClosed$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/curve/linearClosed.js [app-client] (ecmascript) <export default as curveLinearClosed>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const RadarPlot = ({ initialFeatures, data })=>{
    _s();
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    const [features] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        'Attendance',
        'Hours_Studied',
        'Sleep_Hours',
        'Tutoring_Sessions'
    ]);
    const colors = {
        1: "#4f46e5",
        2: "#FFD600",
        3: "#00C853",
        4: "#FF1744"
    };
    // Fixed ranges for each feature
    const featureRanges = {
        'Attendance': 100,
        'Hours_Studied': 50,
        'Sleep_Hours': 10,
        'Tutoring_Sessions': 8
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RadarPlot.useEffect": ()=>{
            if (!data.length) return;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).selectAll("*").remove();
            // Chart dimensions and left shift
            const width = 350 * 2, height = 200 * 1.2;
            const margin = 40;
            const radius = Math.min(width, height) / 2 - margin;
            const levels = 3;
            const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).append("svg").attr("width", width).attr("height", height).append("g")// Increase left shift significantly (from 80 to 200)
            .attr("transform", `translate(${width / 2 - 215},${height / 2})`);
            // Title
            svg.append("text").attr("x", 0).attr("y", -height / 2 + 10).attr("text-anchor", "middle").style("font-size", "10px").style("font-weight", "bold").text("Performance Radar");
            // Bin the data
            const dataBins = {};
            for(let bin = 1; bin <= 4; bin++){
                const binData = data.filter({
                    "RadarPlot.useEffect.binData": (d)=>{
                        const score = +d.Exam_Score;
                        if (bin === 1) return score >= 50 && score < 65;
                        if (bin === 2) return score >= 65 && score < 80;
                        if (bin === 3) return score >= 80 && score < 90;
                        if (bin === 4) return score >= 90 && score <= 100;
                        return false;
                    }
                }["RadarPlot.useEffect.binData"]);
                dataBins[bin] = features.map({
                    "RadarPlot.useEffect": (feat)=>({
                            feature: feat,
                            // Normalize value to [0,1] by dividing by the feature's range
                            value: ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$mean$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__mean$3e$__["mean"])(binData, {
                                "RadarPlot.useEffect": (d)=>+d[feat]
                            }["RadarPlot.useEffect"]) || 0) / featureRanges[feat]
                        })
                }["RadarPlot.useEffect"]);
            }
            // All features use [0,1] normalized scale
            const featureScales = {};
            features.forEach({
                "RadarPlot.useEffect": (feat)=>{
                    featureScales[feat] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
                        0,
                        1
                    ]).range([
                        0,
                        radius
                    ]);
                }
            }["RadarPlot.useEffect"]);
            const angleSlice = Math.PI * 2 / features.length;
            // Draw radar grid circles
            for(let level = 1; level <= levels; level++){
                const r = radius / levels * level;
                svg.append("circle").attr("cx", 0).attr("cy", 0).attr("r", r).attr("fill", "none").attr("stroke", "#ccc").attr("stroke-width", 1);
            }
            // Draw axes and labels
            features.forEach({
                "RadarPlot.useEffect": (feat, i)=>{
                    const angle = i * angleSlice - Math.PI / 2;
                    const lineX = radius * Math.cos(angle);
                    const lineY = radius * Math.sin(angle);
                    svg.append("line").attr("x1", 0).attr("y1", 0).attr("x2", lineX).attr("y2", lineY).attr("stroke", "#999").attr("stroke-width", 1);
                    // Label positioning adjustments
                    let labelX = 1.15 * radius * Math.cos(angle);
                    let labelY = 1.15 * radius * Math.sin(angle);
                    if (i === 0) {
                        labelY -= 5;
                    } else if (i === 1) {
                        labelX += 15;
                        labelY += 5;
                    } else if (i === 2) {
                        labelY += 5;
                    } else if (i === 3) {
                        labelX -= 15;
                        labelY += 5;
                    }
                    const words = feat.split('_');
                    const labelG = svg.append("g").attr("transform", `translate(${labelX},${labelY})`);
                    labelG.selectAll("tspan").data(words).enter().append("text").attr("text-anchor", "middle").attr("dy", {
                        "RadarPlot.useEffect": (d, i)=>i * 6
                    }["RadarPlot.useEffect"]).style("font-size", "7px").text({
                        "RadarPlot.useEffect": (d)=>d
                    }["RadarPlot.useEffect"]);
                }
            }["RadarPlot.useEffect"]);
            // Draw data polygons (before ring values so values are on top)
            Object.entries(dataBins).forEach({
                "RadarPlot.useEffect": ([bin, binData])=>{
                    const points = binData.map({
                        "RadarPlot.useEffect.points": (d, i)=>{
                            const angle = i * angleSlice - Math.PI / 2;
                            const scale = featureScales[d.feature];
                            return {
                                x: scale(d.value) * Math.cos(angle),
                                y: scale(d.value) * Math.sin(angle)
                            };
                        }
                    }["RadarPlot.useEffect.points"]);
                    svg.append("path").datum(points).attr("d", (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__["line"])().x({
                        "RadarPlot.useEffect": (d)=>d.x
                    }["RadarPlot.useEffect"]).y({
                        "RadarPlot.useEffect": (d)=>d.y
                    }["RadarPlot.useEffect"]).curve(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$curve$2f$linearClosed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__curveLinearClosed$3e$__["curveLinearClosed"])).attr("fill", colors[bin]).attr("fill-opacity", 0.3).attr("stroke", colors[bin]).attr("stroke-width", 1.5);
                }
            }["RadarPlot.useEffect"]);
            // Draw ring values (actual value for each axis/feature)
            for(let level = 1; level <= levels; level++){
                features.forEach({
                    "RadarPlot.useEffect": (feat, i)=>{
                        const angle = i * angleSlice - Math.PI / 2;
                        const r = radius / levels * level;
                        const levelValue = (featureRanges[feat] / levels * level).toFixed(1);
                        svg.append("text").attr("x", r * Math.cos(angle)).attr("y", r * Math.sin(angle) - 4).attr("text-anchor", "middle").style("font-size", "7.5px").style("font-weight", "bold").style("fill", "#111").text(levelValue);
                    }
                }["RadarPlot.useEffect"]);
            }
        }
    }["RadarPlot.useEffect"], [
        data,
        features
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: svgRef
    }, void 0, false, {
        fileName: "[project]/src/components/radarPlot.js",
        lineNumber: 176,
        columnNumber: 10
    }, this);
};
_s(RadarPlot, "K43YCulAcb2XDgaznSweX3HWkxU=");
_c = RadarPlot;
const __TURBOPACK__default__export__ = RadarPlot;
var _c;
__turbopack_context__.k.register(_c, "RadarPlot");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Home)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$histogram$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/histogram.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$horizontalBarChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/horizontalBarChart.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$gender$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/gender.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PCPPlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PCPPlot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$linePlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/linePlot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$scatterPlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/scatterPlot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$radarPlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/radarPlot.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
function Home() {
    _s();
    // Filter states
    const [distanceFromHome, setDistanceFromHome] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [parentalEducationLevel, setParentalEducationLevel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [teacherQuality, setTeacherQuality] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [familyIncome, setFamilyIncome] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [motivationLevel, setMotivationLevel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [accessToResources, setAccessToResources] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [parentalInvolvement, setParentalInvolvement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [learningDisabilities, setLearningDisabilities] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [peerInfluence, setPeerInfluence] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [extracurricularActivities, setExtracurricularActivities] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedBins, setSelectedBins] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [gender, setGender] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedIds, setSelectedIds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]); // For brushing/selection
    // BarchartVariables array for bar chart (add new features here)
    const BarchartVariables = [
        'Parental_Involvement',
        'Access_to_Resources',
        'Motivation_Level',
        'Family_Income',
        'Teacher_Quality',
        'Parental_Education_Level',
        'Distance_from_Home',
        'Learning_Disabilities',
        'Peer_Influence',
        'Extracurricular_Activities'
    ];
    // Numeric features for scatter/radar
    const numericFeatures = [
        'Hours_Studied',
        'Attendance',
        'Sleep_Hours',
        'Previous_Scores',
        'Tutoring_Sessions',
        'Physical_Activity',
        'Exam_Score'
    ];
    // PCP order handler
    const [order, setOrder] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        'Hours_Studied',
        'Attendance',
        'Parental_Involvement',
        'Access_to_Resources',
        'Extracurricular_Activities',
        'Sleep_Hours',
        'Previous_Scores',
        'Motivation_Level',
        'Internet_Access',
        'Tutoring_Sessions',
        'Family_Income',
        'Teacher_Quality',
        'School_Type',
        'Peer_Influence',
        'Physical_Activity',
        'Learning_Disabilities',
        'Parental_Education_Level',
        'Distance_from_Home',
        'Gender',
        'Exam_Score'
    ]);
    const handleOrder = (value)=>setOrder(value);
    // Central query parameter object
    const [queryParameter, setQueryParameter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            setQueryParameter({
                Distance_from_Home: distanceFromHome,
                Parental_Education_Level: parentalEducationLevel,
                Teacher_Quality: teacherQuality,
                Family_Income: familyIncome,
                Motivation_Level: motivationLevel,
                Access_to_Resources: accessToResources,
                Parental_Involvement: parentalInvolvement,
                Learning_Disabilities: learningDisabilities,
                Peer_Influence: peerInfluence,
                Extracurricular_Activities: extracurricularActivities,
                bin_id: selectedBins,
                Gender: gender,
                ...selectedIds.length > 0 && {
                    id: selectedIds
                }
            });
        }
    }["Home.useEffect"], [
        distanceFromHome,
        parentalEducationLevel,
        teacherQuality,
        familyIncome,
        motivationLevel,
        accessToResources,
        parentalInvolvement,
        learningDisabilities,
        peerInfluence,
        extracurricularActivities,
        selectedBins,
        gender,
        selectedIds
    ]);
    // Central data state
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // Fetch data from API with all filters and selection
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            const params = new URLSearchParams();
            Object.entries(queryParameter).forEach({
                "Home.useEffect": ([key, value])=>{
                    if (Array.isArray(value)) value.forEach({
                        "Home.useEffect": (v)=>params.append(key, v)
                    }["Home.useEffect"]);
                    else if (value !== undefined && value !== null) params.append(key, value);
                }
            }["Home.useEffect"]);
            const queryString = params.toString() ? `?${params.toString()}` : '';
            fetch(`http://127.0.0.1:5001/data${queryString}`).then({
                "Home.useEffect": (res)=>res.json()
            }["Home.useEffect"]).then(setData).catch({
                "Home.useEffect": (err)=>setData([])
            }["Home.useEffect"]);
        }
    }["Home.useEffect"], [
        queryParameter
    ]);
    // Update functions
    const updateDistanceFromHome = (arr)=>setDistanceFromHome(arr);
    const updateParentalEducationLevel = (arr)=>setParentalEducationLevel(arr);
    const updateTeacherQuality = (arr)=>setTeacherQuality(arr);
    const updateFamilyIncome = (arr)=>setFamilyIncome(arr);
    const updateMotivationLevel = (arr)=>setMotivationLevel(arr);
    const updateAccessToResources = (arr)=>setAccessToResources(arr);
    const updateParentalInvolvement = (arr)=>setParentalInvolvement(arr);
    const updateLearningDisabilities = (arr)=>setLearningDisabilities(arr);
    const updatePeerInfluence = (arr)=>setPeerInfluence(arr);
    const updateExtracurricularActivities = (arr)=>setExtracurricularActivities(arr);
    const updateSelectedBins = (arr)=>setSelectedBins(arr);
    const updateGender = (arr)=>setGender(arr);
    // Handler for brushing in scatter plot
    const handleScatterBrush = (selectedPoints)=>{
        setSelectedIds(selectedPoints);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white text-black",
        style: {
            position: 'relative',
            width: '1560px',
            height: '1200px'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                style: {
                    position: 'absolute',
                    left: '50%',
                    top: 5,
                    transform: 'translateX(-50%)',
                    fontSize: 18,
                    fontWeight: 'bold',
                    zIndex: 2
                },
                children: "STUDENT PERFORMANCE DASHBOARD"
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 134,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 20,
                    top: 35,
                    width: 380,
                    height: 170,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$histogram$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    data: data,
                    selectedBins: selectedBins,
                    updateSelectedBins: updateSelectedBins
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 143,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 139,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 420,
                    top: 35,
                    width: 150,
                    height: 170,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$gender$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    data: data,
                    gender: gender,
                    updateGender: updateGender
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 153,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 149,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 610,
                    top: 35,
                    width: 350,
                    height: 170,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$linePlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    data: data
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 163,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 159,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 980,
                    top: 35,
                    width: 570,
                    height: 510,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$horizontalBarChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    data: data,
                    variables: BarchartVariables,
                    distanceFromHome: distanceFromHome,
                    updateDistanceFromHome: updateDistanceFromHome,
                    parentalEducationLevel: parentalEducationLevel,
                    updateParentalEducationLevel: updateParentalEducationLevel,
                    teacherQuality: teacherQuality,
                    updateTeacherQuality: updateTeacherQuality,
                    familyIncome: familyIncome,
                    updateFamilyIncome: updateFamilyIncome,
                    motivationLevel: motivationLevel,
                    updateMotivationLevel: updateMotivationLevel,
                    accessToResources: accessToResources,
                    updateAccessToResources: updateAccessToResources,
                    parentalInvolvement: parentalInvolvement,
                    updateParentalInvolvement: updateParentalInvolvement,
                    learningDisabilities: learningDisabilities,
                    updateLearningDisabilities: updateLearningDisabilities,
                    peerInfluence: peerInfluence,
                    updatePeerInfluence: updatePeerInfluence,
                    extracurricularActivities: extracurricularActivities,
                    updateExtracurricularActivities: updateExtracurricularActivities,
                    selectedBins: selectedBins
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 170,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 166,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 20,
                    top: 220,
                    width: 300,
                    height: 250,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$radarPlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    initialFeatures: [
                        'Hours_Studied',
                        'Attendance',
                        'Sleep_Hours',
                        'Previous_Scores'
                    ],
                    data: data
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 202,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 198,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 580,
                    top: 220,
                    width: 380,
                    height: 240,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$scatterPlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    data: data,
                    numericFeatures: numericFeatures,
                    onBrush: handleScatterBrush
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 211,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 207,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 20,
                    top: 600,
                    width: 1510,
                    height: 300,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PCPPlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    order: order,
                    setOrder: handleOrder,
                    data: data
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 224,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 220,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 133,
        columnNumber: 5
    }, this);
}
_s(Home, "UlZTk0DIFUVEpK10b9ytYtxRHyk=");
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_1078ae63._.js.map