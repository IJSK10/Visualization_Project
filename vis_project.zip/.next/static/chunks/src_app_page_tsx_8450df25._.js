(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_0d740b48._.js",
  "static/chunks/src_3f5d213f._.js"
],
    source: "dynamic"
});
