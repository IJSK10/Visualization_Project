(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/components/histogram.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-client] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/band.js [app-client] (ecmascript) <export default as scaleBand>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-client] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/max.js [app-client] (ecmascript) <export default as max>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-axis/src/axis.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const BIN_RANGES = [
    {
        bin: 1,
        label: "50–64",
        range: [
            50,
            65
        ],
        color: "#4f46e5"
    },
    {
        bin: 2,
        label: "65–79",
        range: [
            65,
            80
        ],
        color: "#FFD600"
    },
    {
        bin: 3,
        label: "80–89",
        range: [
            80,
            90
        ],
        color: "#00C853"
    },
    {
        bin: 4,
        label: "90–100",
        range: [
            90,
            101
        ],
        color: "#FF1744"
    }
];
const Histogram = ({ data, selectedBins, updateSelectedBins })=>{
    _s();
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Histogram.useEffect": ()=>{
            if (!data) return;
            drawHistogram(data);
        }
    }["Histogram.useEffect"], [
        data,
        selectedBins
    ]);
    function drawHistogram(data) {
        const margin = {
            top: 50,
            right: 100,
            bottom: 60,
            left: 40
        };
        const width = (400 - margin.left - margin.right) * 1.3;
        const height = (200 - margin.top - margin.bottom) * 1.4; // Reduced height by 10%
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).selectAll("*").remove();
        const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).attr('width', width + margin.left + margin.right).attr('height', height + margin.top + margin.bottom).append('g').attr('transform', `translate(${margin.left},${margin.top})`);
        const binCounts = BIN_RANGES.map(({ bin, range, label, color })=>({
                bin,
                label,
                color,
                count: data.filter((d)=>+d.Exam_Score >= range[0] && +d.Exam_Score < range[1]).length
            }));
        const x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(binCounts.map((b)=>b.label)).range([
            0,
            width
        ]).padding(0.1);
        const y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
            0,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(binCounts, (b)=>b.count) || 1
        ]).nice().range([
            height,
            0
        ]);
        const getFill = (binObj)=>{
            if (selectedBins.length === 0) return binObj.color;
            return selectedBins.includes(binObj.bin) ? binObj.color : "#ccc";
        };
        // Bars
        svg.selectAll(".bar").data(binCounts).enter().append("rect").attr("class", "bar").attr("x", (d)=>x(d.label)).attr("y", (d)=>y(d.count)).attr("width", x.bandwidth()).attr("height", (d)=>height - y(d.count)).attr("fill", getFill).style("cursor", "pointer").on("click", (event, d)=>{
            if (selectedBins.includes(d.bin)) {
                updateSelectedBins(selectedBins.filter((b)=>b !== d.bin));
            } else {
                updateSelectedBins([
                    ...selectedBins,
                    d.bin
                ].sort());
            }
        });
        // Value labels
        svg.selectAll(".bar-label").data(binCounts).enter().append("text").attr("class", "bar-label").attr("x", (d)=>x(d.label) + x.bandwidth() / 2).attr("y", (d)=>y(d.count) - 5).attr("text-anchor", "middle").style("font-size", "16px").text((d)=>d.count);
        // X-axis with ticks (labels) and clickable
        const xAxis = svg.append("g").attr("transform", `translate(0,${height})`).call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["axisBottom"])(x).tickSize(0));
        xAxis.selectAll("text").style("cursor", "pointer").attr("fill", (d)=>{
            const binObj = binCounts.find((b)=>b.label === d);
            return getFill(binObj);
        }).on("click", function(event, label) {
            const binObj = binCounts.find((b)=>b.label === label);
            if (!binObj) return;
            if (selectedBins.includes(binObj.bin)) {
                updateSelectedBins(selectedBins.filter((b)=>b !== binObj.bin));
            } else {
                updateSelectedBins([
                    ...selectedBins,
                    binObj.bin
                ].sort());
            }
        });
        // Remove x-axis line
        xAxis.select("path.domain").attr("stroke", "none");
        // X-axis label below the ticks (reduced gap)
        svg.append("text").attr("x", width / 2).attr("y", height + 25) // Reduced gap
        .attr("text-anchor", "middle").style("font-size", "14px") // Reduced font size
        .style("font-weight", "bold").text("Exam Score Bin");
        // Y-axis label only (no ticks/numbers)
        svg.append("text").attr("transform", `rotate(-90)`).attr("x", -height / 2).attr("y", -15).attr("text-anchor", "middle").style("font-size", "14px") // Reduced font size
        .style("font-weight", "bold").text("Count");
        // Remove y-axis ticks and numbers
        svg.append("g").call((g)=>g.selectAll(".tick").remove()).call((g)=>g.selectAll("path.domain").remove());
        // Title (reduced font size)
        svg.append("text").attr("x", width / 2).attr("y", -30).attr("text-anchor", "middle").style("font-size", "18px") // Reduced font size
        .style("font-weight", "bold").text("Exam Score Distribution");
        // Legend (spaced from bars)
        const legend = svg.append("g").attr("transform", `translate(${width + 20}, 0)`);
        BIN_RANGES.forEach((bin, i)=>{
            legend.append("rect").attr("x", 0).attr("y", i * 22).attr("width", 16).attr("height", 16).attr("fill", bin.color);
            legend.append("text").attr("x", 24).attr("y", i * 22 + 12).attr("font-size", "15px").attr("alignment-baseline", "middle").text(bin.label);
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        ref: svgRef
    }, void 0, false, {
        fileName: "[project]/src/components/histogram.js",
        lineNumber: 164,
        columnNumber: 10
    }, this);
};
_s(Histogram, "89Ty783ABEwsfMbSOeu9vscWF34=");
_c = Histogram;
const __TURBOPACK__default__export__ = Histogram;
var _c;
__turbopack_context__.k.register(_c, "Histogram");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/horizontalBarChart.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-client] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/max.js [app-client] (ecmascript) <export default as max>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-client] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/band.js [app-client] (ecmascript) <export default as scaleBand>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
// Define bin ranges and colors
const BIN_RANGES = [
    {
        bin: 1,
        label: "50–64",
        range: [
            50,
            65
        ],
        color: "#4f46e5"
    },
    {
        bin: 2,
        label: "65–79",
        range: [
            65,
            80
        ],
        color: "#FFD600"
    },
    {
        bin: 3,
        label: "80–89",
        range: [
            80,
            90
        ],
        color: "#00C853"
    },
    {
        bin: 4,
        label: "90–100",
        range: [
            90,
            101
        ],
        color: "#FF1744"
    }
];
// All possible categories for each variable
const ALL_CATEGORIES = {
    Distance_from_Home: [
        "Near",
        "Moderate",
        "Far"
    ],
    Parental_Education_Level: [
        "High School",
        "College",
        "Postgraduate"
    ],
    Teacher_Quality: [
        "Low",
        "Medium",
        "High"
    ],
    Family_Income: [
        "Low",
        "Medium",
        "High"
    ],
    Motivation_Level: [
        "Low",
        "Medium",
        "High"
    ],
    Access_to_Resources: [
        "Low",
        "Medium",
        "High"
    ],
    Parental_Involvement: [
        "Low",
        "Medium",
        "High"
    ],
    Learning_Disabilities: [
        "Yes",
        "No"
    ],
    Peer_Influence: [
        "Positive",
        "Neutral",
        "Negative"
    ],
    Extracurricular_Activities: [
        "Yes",
        "No"
    ]
};
function getBin(score) {
    for (const bin of BIN_RANGES){
        if (score >= bin.range[0] && score < bin.range[1]) return bin;
    }
    return null;
}
const HorizontalBarChart = ({ data, variables, distanceFromHome, updateDistanceFromHome, parentalEducationLevel, updateParentalEducationLevel, teacherQuality, updateTeacherQuality, familyIncome, updateFamilyIncome, motivationLevel, updateMotivationLevel, accessToResources, updateAccessToResources, parentalInvolvement, updateParentalInvolvement, learningDisabilities, updateLearningDisabilities, peerInfluence, updatePeerInfluence, extracurricularActivities, updateExtracurricularActivities, selectedBins })=>{
    _s();
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    // Helper to get state array and updater for a variable
    const getStateAndUpdater = (varName)=>{
        switch(varName){
            case "Distance_from_Home":
                return [
                    distanceFromHome,
                    updateDistanceFromHome
                ];
            case "Parental_Education_Level":
                return [
                    parentalEducationLevel,
                    updateParentalEducationLevel
                ];
            case "Teacher_Quality":
                return [
                    teacherQuality,
                    updateTeacherQuality
                ];
            case "Family_Income":
                return [
                    familyIncome,
                    updateFamilyIncome
                ];
            case "Motivation_Level":
                return [
                    motivationLevel,
                    updateMotivationLevel
                ];
            case "Access_to_Resources":
                return [
                    accessToResources,
                    updateAccessToResources
                ];
            case "Parental_Involvement":
                return [
                    parentalInvolvement,
                    updateParentalInvolvement
                ];
            case "Learning_Disabilities":
                return [
                    learningDisabilities,
                    updateLearningDisabilities
                ];
            case "Peer_Influence":
                return [
                    peerInfluence,
                    updatePeerInfluence
                ];
            case "Extracurricular_Activities":
                return [
                    extracurricularActivities,
                    updateExtracurricularActivities
                ];
            default:
                return [
                    [],
                    ()=>{}
                ];
        }
    };
    // Reset all filters
    const resetAllFilters = ()=>{
        updateDistanceFromHome([]);
        updateParentalEducationLevel([]);
        updateTeacherQuality([]);
        updateFamilyIncome([]);
        updateMotivationLevel([]);
        updateAccessToResources([]);
        updateParentalInvolvement([]);
        updateLearningDisabilities([]);
        updatePeerInfluence([]);
        updateExtracurricularActivities([]);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HorizontalBarChart.useEffect": ()=>{
            if (!data) return;
            // Prepare data for stacked bar chart
            const processedData = variables.map({
                "HorizontalBarChart.useEffect.processedData": (varName)=>{
                    const allCategories = ALL_CATEGORIES[varName] || [];
                    const counts = allCategories.map({
                        "HorizontalBarChart.useEffect.processedData.counts": (cat)=>{
                            const filtered = data.filter({
                                "HorizontalBarChart.useEffect.processedData.counts.filtered": (d)=>d[varName] === cat
                            }["HorizontalBarChart.useEffect.processedData.counts.filtered"]);
                            const binCounts = BIN_RANGES.map({
                                "HorizontalBarChart.useEffect.processedData.counts.binCounts": (bin)=>({
                                        bin: bin.bin,
                                        color: bin.color,
                                        count: filtered.filter({
                                            "HorizontalBarChart.useEffect.processedData.counts.binCounts": (d)=>{
                                                const score = +d.Exam_Score;
                                                return score >= bin.range[0] && score < bin.range[1];
                                            }
                                        }["HorizontalBarChart.useEffect.processedData.counts.binCounts"]).length
                                    })
                            }["HorizontalBarChart.useEffect.processedData.counts.binCounts"]);
                            const total = binCounts.reduce({
                                "HorizontalBarChart.useEffect.processedData.counts.total": (sum, b)=>sum + b.count
                            }["HorizontalBarChart.useEffect.processedData.counts.total"], 0);
                            return {
                                category: cat,
                                binCounts,
                                total
                            };
                        }
                    }["HorizontalBarChart.useEffect.processedData.counts"]);
                    return {
                        varName,
                        counts
                    };
                }
            }["HorizontalBarChart.useEffect.processedData"]);
            drawChart(processedData);
        // eslint-disable-next-line
        }
    }["HorizontalBarChart.useEffect"], [
        data,
        variables,
        distanceFromHome,
        parentalEducationLevel,
        teacherQuality,
        familyIncome,
        motivationLevel,
        accessToResources,
        parentalInvolvement,
        learningDisabilities,
        peerInfluence,
        extracurricularActivities,
        selectedBins
    ]);
    const drawChart = (dataset)=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(ref.current).selectAll("*").remove();
        // Dimensions
        const width = 580, height = 800;
        const margin = {
            top: 60,
            right: 40,
            bottom: 100,
            left: 230
        };
        // Create SVG
        const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(ref.current).append('svg').attr('width', width).attr('height', height);
        // Title group for title and button
        const titleGroup = svg.append('g');
        // Title
        titleGroup.append('text').attr('x', width / 2 - 40).attr('y', 35).attr('text-anchor', 'middle').style('font-size', '20px').style('font-weight', 'bold').text('Student Performance Factors Distribution');
        // Reset All icon button (circle with X)
        const buttonSize = 20;
        const buttonX = width / 2 + 170;
        const buttonY = 18;
        const resetButton = titleGroup.append('g').attr('transform', `translate(${buttonX},${buttonY})`).style('cursor', 'pointer').on('click', resetAllFilters).on('mouseenter', function() {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).select('circle').attr('fill', '#f3f4f6');
        }).on('mouseleave', function() {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).select('circle').attr('fill', '#fff');
        });
        resetButton.append('circle').attr('cx', buttonSize / 2).attr('cy', buttonSize / 2).attr('r', buttonSize / 2).attr('fill', '#fff').attr('stroke', '#4f46e5').attr('stroke-width', 1.5);
        resetButton.append('path').attr('d', 'M10 10L22 22M10 22L22 10').attr('transform', `translate(${buttonSize / 2 - 16},${buttonSize / 2 - 16})`).attr('stroke', '#4f46e5').attr('stroke-width', 2).attr('stroke-linecap', 'round');
        // Max total for scaling
        const maxCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(dataset.flatMap((d)=>d.counts.map((c)=>c.total))) || 1;
        // Scales
        const xScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
            0,
            maxCount
        ]).range([
            margin.left,
            width - margin.right
        ]);
        const yScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(dataset.map((d)=>d.varName)).range([
            height - margin.bottom,
            margin.top
        ]).padding(0.2);
        // Create variable groups
        const variableGroups = svg.selectAll('.variable-group').data(dataset).enter().append('g').attr('transform', (d)=>`translate(0,${yScale(d.varName)})`);
        // Add bars and labels
        variableGroups.each(function(d) {
            const [currentArray, updateArray] = getStateAndUpdater(d.varName);
            const categoryScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(d.counts.map((c)=>c.category)).range([
                0,
                yScale.bandwidth()
            ]).padding(0.05);
            const group = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this);
            // Stacked bars
            group.selectAll('g.category').data(d.counts).enter().append('g').attr('class', 'category').attr('transform', (c)=>`translate(0,${categoryScale(c.category)})`).each(function(c) {
                let x0 = margin.left;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this).selectAll('rect').data(c.binCounts).enter().append('rect').attr('x', (bin, i)=>{
                    const prevWidth = c.binCounts.slice(0, i).reduce((sum, b)=>sum + (xScale(b.count) - xScale(0)), 0);
                    return x0 + prevWidth;
                }).attr('y', 0).attr('width', (bin)=>Math.max(0, xScale(bin.count) - xScale(0))).attr('height', categoryScale.bandwidth() * 0.95).attr('fill', (bin)=>currentArray.length === 0 || currentArray.includes(c.category) ? bin.color : '#ccc').attr('rx', 4).style('cursor', 'pointer').on('click', function(event) {
                    event.stopPropagation();
                    if (currentArray.includes(c.category)) {
                        updateArray(currentArray.filter((val)=>val !== c.category));
                    } else {
                        updateArray([
                            ...currentArray,
                            c.category
                        ]);
                    }
                });
            });
            // Total count labels (top of stacked bar)
            group.selectAll('.total-label').data(d.counts).enter().append('text').attr('class', 'total-label').attr('x', (c)=>margin.left + c.binCounts.reduce((sum, b)=>sum + (xScale(b.count) - xScale(0)), 0) + 12).attr('y', (c)=>categoryScale(c.category) + 11).attr('text-anchor', 'start').style('font-size', '0.7em').style('fill', 'black').text((c)=>c.total);
            // Category labels (right side, clickable)
            group.selectAll('.category-label').data(d.counts).enter().append('text').attr('class', 'category-label').attr('x', (c)=>margin.left - 5).attr('y', (c)=>categoryScale(c.category) + categoryScale.bandwidth() / 2).attr('dy', '0.35em').attr('text-anchor', 'end').style('font-size', '0.7em').style('fill', 'black').style('cursor', 'pointer').on('click', function(event, c) {
                event.stopPropagation();
                if (currentArray.includes(c.category)) {
                    updateArray(currentArray.filter((val)=>val !== c.category));
                } else {
                    updateArray([
                        ...currentArray,
                        c.category
                    ]);
                }
            }).text((c)=>c.category);
        });
        // Variable labels (multi-line, clickable to reset, moved further left)
        variableGroups.append('text').attr('x', margin.left - 80).attr('y', yScale.bandwidth() / 2 - 12).attr('text-anchor', 'end').attr('dominant-baseline', 'middle').style('font-size', '0.90em').style('cursor', 'pointer').style('font-weight', 'bold').on('click', function(event, d) {
            event.stopPropagation();
            const [, updateArray] = getStateAndUpdater(d.varName);
            updateArray([]); // Reset filter
        }).selectAll('tspan').data((d)=>d.varName.split('_')).enter().append('tspan').attr('x', margin.left - 80).attr('dy', (d, i)=>i === 0 ? 0 : '0.9em').text((d)=>d.charAt(0).toUpperCase() + d.slice(1).toLowerCase());
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref
    }, void 0, false, {
        fileName: "[project]/src/components/horizontalBarChart.js",
        lineNumber: 290,
        columnNumber: 10
    }, this);
};
_s(HorizontalBarChart, "8uVE59eA/r6b92xF80p7sH8rXLk=");
_c = HorizontalBarChart;
const __TURBOPACK__default__export__ = HorizontalBarChart;
var _c;
__turbopack_context__.k.register(_c, "HorizontalBarChart");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/scatterPlot.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-client] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-client] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/min.js [app-client] (ecmascript) <export default as min>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/max.js [app-client] (ecmascript) <export default as max>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$brush$2f$src$2f$brush$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__brush$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-brush/src/brush.js [app-client] (ecmascript) <export default as brush>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-axis/src/axis.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const ScatterPlotMatrix = ({ numericFeatures, data, onBrush })=>{
    _s();
    const [xIndex, setXIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [yIndex, setYIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    // Navigation handlers
    const moveXLeft = ()=>setXIndex((prev)=>prev > 0 ? prev - 1 : numericFeatures.length - 1);
    const moveXRight = ()=>setXIndex((prev)=>prev < numericFeatures.length - 1 ? prev + 1 : 0);
    const moveYLeft = ()=>setYIndex((prev)=>prev > 0 ? prev - 1 : numericFeatures.length - 1);
    const moveYRight = ()=>setYIndex((prev)=>prev < numericFeatures.length - 1 ? prev + 1 : 0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ScatterPlotMatrix.useEffect": ()=>{
            if (!data.length || !numericFeatures) return;
            const xFeature = numericFeatures[xIndex];
            const yFeature = numericFeatures[yIndex];
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).selectAll("*").remove();
            const binColors = {
                1: "#4f46e5",
                2: "#FFD600",
                3: "#00C853",
                4: "#FF1744" // red
            };
            const margin = {
                top: 50,
                right: 50,
                bottom: 50,
                left: 60
            };
            const width = 380 - margin.left - margin.right;
            const height = 240 - margin.top - margin.bottom;
            const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).attr('width', width + margin.left + margin.right).attr('height', height + margin.top + margin.bottom).append('g').attr('transform', `translate(${margin.left},${margin.top})`);
            const x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__["min"])(data, {
                    "ScatterPlotMatrix.useEffect.x": (d)=>+d[xFeature]
                }["ScatterPlotMatrix.useEffect.x"]) * 0.9,
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(data, {
                    "ScatterPlotMatrix.useEffect.x": (d)=>+d[xFeature]
                }["ScatterPlotMatrix.useEffect.x"]) * 1.1
            ]).range([
                0,
                width
            ]);
            const y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__["min"])(data, {
                    "ScatterPlotMatrix.useEffect.y": (d)=>+d[yFeature]
                }["ScatterPlotMatrix.useEffect.y"]) * 0.9,
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(data, {
                    "ScatterPlotMatrix.useEffect.y": (d)=>+d[yFeature]
                }["ScatterPlotMatrix.useEffect.y"]) * 1.1
            ]).range([
                height,
                0
            ]);
            // Brushing
            const brush = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$brush$2f$src$2f$brush$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__brush$3e$__["brush"])().extent([
                [
                    0,
                    0
                ],
                [
                    width,
                    height
                ]
            ]).on('end', {
                "ScatterPlotMatrix.useEffect.brush": (event)=>{
                    if (!event.selection) {
                        onBrush([]);
                        return;
                    }
                    const [[x0, y0], [x1, y1]] = event.selection;
                    const selectedPoints = data.filter({
                        "ScatterPlotMatrix.useEffect.brush.selectedPoints": (d)=>{
                            const cx = x(+d[xFeature]);
                            const cy = y(+d[yFeature]);
                            return cx >= x0 && cx <= x1 && cy >= y0 && cy <= y1;
                        }
                    }["ScatterPlotMatrix.useEffect.brush.selectedPoints"]);
                    onBrush(selectedPoints.map({
                        "ScatterPlotMatrix.useEffect.brush": (d)=>d.id
                    }["ScatterPlotMatrix.useEffect.brush"]));
                }
            }["ScatterPlotMatrix.useEffect.brush"]);
            svg.append("g").attr("class", "brush").call(brush);
            // Points
            svg.selectAll('circle').data(data).enter().append('circle').attr('cx', {
                "ScatterPlotMatrix.useEffect": (d)=>x(+d[xFeature])
            }["ScatterPlotMatrix.useEffect"]).attr('cy', {
                "ScatterPlotMatrix.useEffect": (d)=>y(+d[yFeature])
            }["ScatterPlotMatrix.useEffect"]).attr('r', 4).style('fill', {
                "ScatterPlotMatrix.useEffect": (d)=>binColors[d.bin_id] || '#bbb'
            }["ScatterPlotMatrix.useEffect"]).style('opacity', 0.7);
            // X axis
            svg.append('g').attr('transform', `translate(0,${height})`).call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["axisBottom"])(x));
            // Y axis
            svg.append('g').call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["axisLeft"])(y));
            // X axis navigation
            const xAxisLabel = svg.append('g').attr('transform', `translate(${width / 2}, ${height + 40})`);
            xAxisLabel.append('rect').attr('x', -85).attr('y', -15).attr('width', 20).attr('height', 20).attr('rx', 3).attr('fill', 'steelblue').style('cursor', 'pointer').on('click', moveXLeft);
            xAxisLabel.append('text').attr('x', -75).attr('y', 0).attr('text-anchor', 'middle').attr('fill', 'white').style('pointer-events', 'none').text('←');
            xAxisLabel.append('text').attr('x', 0).attr('y', 0).attr('text-anchor', 'middle').style('font-weight', 'bold').text(xFeature);
            xAxisLabel.append('rect').attr('x', 65).attr('y', -15).attr('width', 20).attr('height', 20).attr('rx', 3).attr('fill', 'steelblue').style('cursor', 'pointer').on('click', moveXRight);
            xAxisLabel.append('text').attr('x', 75).attr('y', 0).attr('text-anchor', 'middle').attr('fill', 'white').style('pointer-events', 'none').text('→');
            // Y axis navigation
            const yAxisLabel = svg.append('g').attr('transform', `translate(${-40}, ${height / 2}) rotate(-90)`);
            yAxisLabel.append('rect').attr('x', -85).attr('y', -15).attr('width', 20).attr('height', 20).attr('rx', 3).attr('fill', 'steelblue').style('cursor', 'pointer').on('click', moveYLeft);
            yAxisLabel.append('text').attr('x', -75).attr('y', 0).attr('text-anchor', 'middle').attr('fill', 'white').style('pointer-events', 'none').text('←');
            yAxisLabel.append('text').attr('x', 0).attr('y', 0).attr('text-anchor', 'middle').style('font-weight', 'bold').text(yFeature);
            yAxisLabel.append('rect').attr('x', 65).attr('y', -15).attr('width', 20).attr('height', 20).attr('rx', 3).attr('fill', 'steelblue').style('cursor', 'pointer').on('click', moveYRight);
            yAxisLabel.append('text').attr('x', 75).attr('y', 0).attr('text-anchor', 'middle').attr('fill', 'white').style('pointer-events', 'none').text('→');
            // Title
            svg.append('text').attr('x', width / 2).attr('y', -25).attr('text-anchor', 'middle').style('font-size', '16px').style('font-weight', 'bold').text(`${yFeature} vs ${xFeature}`);
        }
    }["ScatterPlotMatrix.useEffect"], [
        data,
        xIndex,
        yIndex,
        numericFeatures,
        onBrush
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col items-center",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            ref: svgRef,
            width: 380,
            height: 240
        }, void 0, false, {
            fileName: "[project]/src/components/scatterPlot.js",
            lineNumber: 141,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/scatterPlot.js",
        lineNumber: 140,
        columnNumber: 5
    }, this);
};
_s(ScatterPlotMatrix, "psAzQupM+MAval2KIyVMyhurTtg=");
_c = ScatterPlotMatrix;
const __TURBOPACK__default__export__ = ScatterPlotMatrix;
var _c;
__turbopack_context__.k.register(_c, "ScatterPlotMatrix");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Home)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$histogram$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/histogram.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$horizontalBarChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/horizontalBarChart.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$scatterPlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/scatterPlot.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function Home() {
    _s();
    // Filter states
    const [distanceFromHome, setDistanceFromHome] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [parentalEducationLevel, setParentalEducationLevel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [teacherQuality, setTeacherQuality] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [familyIncome, setFamilyIncome] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [motivationLevel, setMotivationLevel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [accessToResources, setAccessToResources] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [parentalInvolvement, setParentalInvolvement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [learningDisabilities, setLearningDisabilities] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [peerInfluence, setPeerInfluence] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [extracurricularActivities, setExtracurricularActivities] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedBins, setSelectedBins] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [gender, setGender] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedIds, setSelectedIds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]); // For brushing/selection
    // BarchartVariables array for bar chart (add new features here)
    const BarchartVariables = [
        'Parental_Involvement',
        'Access_to_Resources',
        'Motivation_Level',
        'Family_Income',
        'Teacher_Quality',
        'Parental_Education_Level',
        'Distance_from_Home',
        'Learning_Disabilities',
        'Peer_Influence',
        'Extracurricular_Activities'
    ];
    // Numeric features for scatter/radar
    const numericFeatures = [
        'Hours_Studied',
        'Attendance',
        'Sleep_Hours',
        'Previous_Scores',
        'Tutoring_Sessions',
        'Physical_Activity',
        'Exam_Score'
    ];
    // PCP order handler
    const [order, setOrder] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        'Hours_Studied',
        'Attendance',
        'Parental_Involvement',
        'Access_to_Resources',
        'Extracurricular_Activities',
        'Sleep_Hours',
        'Previous_Scores',
        'Motivation_Level',
        'Internet_Access',
        'Tutoring_Sessions',
        'Family_Income',
        'Teacher_Quality',
        'School_Type',
        'Peer_Influence',
        'Physical_Activity',
        'Learning_Disabilities',
        'Parental_Education_Level',
        'Distance_from_Home',
        'Gender',
        'Exam_Score'
    ]);
    const handleOrder = (value)=>setOrder(value);
    // Central query parameter object
    const [queryParameter, setQueryParameter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            setQueryParameter({
                Distance_from_Home: distanceFromHome,
                Parental_Education_Level: parentalEducationLevel,
                Teacher_Quality: teacherQuality,
                Family_Income: familyIncome,
                Motivation_Level: motivationLevel,
                Access_to_Resources: accessToResources,
                Parental_Involvement: parentalInvolvement,
                Learning_Disabilities: learningDisabilities,
                Peer_Influence: peerInfluence,
                Extracurricular_Activities: extracurricularActivities,
                bin_id: selectedBins,
                Gender: gender,
                ...selectedIds.length > 0 && {
                    id: selectedIds
                }
            });
        }
    }["Home.useEffect"], [
        distanceFromHome,
        parentalEducationLevel,
        teacherQuality,
        familyIncome,
        motivationLevel,
        accessToResources,
        parentalInvolvement,
        learningDisabilities,
        peerInfluence,
        extracurricularActivities,
        selectedBins,
        gender,
        selectedIds
    ]);
    // Central data state
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // Fetch data from API with all filters and selection
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            const params = new URLSearchParams();
            Object.entries(queryParameter).forEach({
                "Home.useEffect": ([key, value])=>{
                    if (Array.isArray(value)) value.forEach({
                        "Home.useEffect": (v)=>params.append(key, v)
                    }["Home.useEffect"]);
                    else if (value !== undefined && value !== null) params.append(key, value);
                }
            }["Home.useEffect"]);
            const queryString = params.toString() ? `?${params.toString()}` : '';
            fetch(`http://127.0.0.1:5001/data${queryString}`).then({
                "Home.useEffect": (res)=>res.json()
            }["Home.useEffect"]).then(setData).catch({
                "Home.useEffect": (err)=>setData([])
            }["Home.useEffect"]);
        }
    }["Home.useEffect"], [
        queryParameter
    ]);
    // Update functions
    const updateDistanceFromHome = (arr)=>setDistanceFromHome(arr);
    const updateParentalEducationLevel = (arr)=>setParentalEducationLevel(arr);
    const updateTeacherQuality = (arr)=>setTeacherQuality(arr);
    const updateFamilyIncome = (arr)=>setFamilyIncome(arr);
    const updateMotivationLevel = (arr)=>setMotivationLevel(arr);
    const updateAccessToResources = (arr)=>setAccessToResources(arr);
    const updateParentalInvolvement = (arr)=>setParentalInvolvement(arr);
    const updateLearningDisabilities = (arr)=>setLearningDisabilities(arr);
    const updatePeerInfluence = (arr)=>setPeerInfluence(arr);
    const updateExtracurricularActivities = (arr)=>setExtracurricularActivities(arr);
    const updateSelectedBins = (arr)=>setSelectedBins(arr);
    const updateGender = (arr)=>setGender(arr);
    // Handler for brushing in scatter plot
    const handleScatterBrush = (selectedPoints)=>{
        setSelectedIds(selectedPoints);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white text-black",
        style: {
            position: 'relative',
            width: '1560px',
            height: '1200px'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                style: {
                    position: 'absolute',
                    left: '50%',
                    top: 5,
                    transform: 'translateX(-50%)',
                    fontSize: 18,
                    fontWeight: 'bold',
                    zIndex: 2
                },
                children: "STUDENT PERFORMANCE DASHBOARD"
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 134,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 20,
                    top: 35,
                    width: 480,
                    height: 220,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$histogram$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    data: data,
                    selectedBins: selectedBins,
                    updateSelectedBins: updateSelectedBins
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 143,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 139,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 980,
                    top: 35,
                    width: 570,
                    height: 510,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$horizontalBarChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    data: data,
                    variables: BarchartVariables,
                    distanceFromHome: distanceFromHome,
                    updateDistanceFromHome: updateDistanceFromHome,
                    parentalEducationLevel: parentalEducationLevel,
                    updateParentalEducationLevel: updateParentalEducationLevel,
                    teacherQuality: teacherQuality,
                    updateTeacherQuality: updateTeacherQuality,
                    familyIncome: familyIncome,
                    updateFamilyIncome: updateFamilyIncome,
                    motivationLevel: motivationLevel,
                    updateMotivationLevel: updateMotivationLevel,
                    accessToResources: accessToResources,
                    updateAccessToResources: updateAccessToResources,
                    parentalInvolvement: parentalInvolvement,
                    updateParentalInvolvement: updateParentalInvolvement,
                    learningDisabilities: learningDisabilities,
                    updateLearningDisabilities: updateLearningDisabilities,
                    peerInfluence: peerInfluence,
                    updatePeerInfluence: updatePeerInfluence,
                    extracurricularActivities: extracurricularActivities,
                    updateExtracurricularActivities: updateExtracurricularActivities,
                    selectedBins: selectedBins
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 164,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 160,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: 'absolute',
                    left: 580,
                    top: 220,
                    width: 380,
                    height: 240,
                    zIndex: 1,
                    background: '#f9f9f9',
                    borderRadius: 10,
                    boxShadow: '0 2px 8px #0001'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$scatterPlot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    data: data,
                    numericFeatures: numericFeatures,
                    onBrush: handleScatterBrush
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 205,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 201,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 133,
        columnNumber: 5
    }, this);
}
_s(Home, "UlZTk0DIFUVEpK10b9ytYtxRHyk=");
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_f183706b._.js.map