(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/components/histogram.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-client] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$bin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__histogram$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/bin.js [app-client] (ecmascript) <export default as histogram>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$extent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__extent$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/extent.js [app-client] (ecmascript) <export default as extent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$range$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__range$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/range.js [app-client] (ecmascript) <export default as range>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/band.js [app-client] (ecmascript) <export default as scaleBand>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-client] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/max.js [app-client] (ecmascript) <export default as max>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-axis/src/axis.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const Histogram = ()=>{
    _s();
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const svgRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Histogram.useEffect": ()=>{
            const fetchData = {
                "Histogram.useEffect.fetchData": async ()=>{
                    const response = await fetch('http://127.0.0.1:5001/data');
                    const result = await response.json();
                    setData(result);
                }
            }["Histogram.useEffect.fetchData"];
            fetchData();
        }
    }["Histogram.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Histogram.useEffect": ()=>{
            if (data.length > 0) {
                const scores = data.map({
                    "Histogram.useEffect.scores": (d)=>d.Exam_Score
                }["Histogram.useEffect.scores"]);
                const margin = {
                    top: 20,
                    right: 30,
                    bottom: 40,
                    left: 40
                };
                const width = 400 - margin.left - margin.right;
                const height = 200 - margin.top - margin.bottom;
                // Clear previous SVG contents
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).selectAll("*").remove();
                const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(svgRef.current).attr('width', width + margin.left + margin.right).attr('height', height + margin.top + margin.bottom).append('g').attr('transform', `translate(${margin.left},${margin.top})`);
                const histogram = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$bin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__histogram$3e$__["histogram"])().value({
                    "Histogram.useEffect.histogram": (d)=>d
                }["Histogram.useEffect.histogram"]).domain((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$extent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__extent$3e$__["extent"])(scores)).thresholds((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$range$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__range$3e$__["range"])(50, 102, 13));
                const bins = histogram(scores);
                const x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(bins.map({
                    "Histogram.useEffect.x": (d)=>`${d.x0} - ${d.x1}`
                }["Histogram.useEffect.x"])).range([
                    0,
                    width
                ]).padding(0.1);
                const y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
                    0,
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(bins, {
                        "Histogram.useEffect.y": (d)=>d.length
                    }["Histogram.useEffect.y"])
                ]).nice().range([
                    height,
                    0
                ]);
                // Create bars
                svg.selectAll('.bar').data(bins).enter().append('rect').attr('class', 'bar').attr('x', {
                    "Histogram.useEffect": (d)=>x(`${d.x0} - ${d.x1}`)
                }["Histogram.useEffect"]).attr('y', {
                    "Histogram.useEffect": (d)=>y(d.length)
                }["Histogram.useEffect"]).attr('width', x.bandwidth()).attr('height', {
                    "Histogram.useEffect": (d)=>height - y(d.length)
                }["Histogram.useEffect"]).attr('fill', 'steelblue');
                // Add text labels
                svg.selectAll('.bar-label').data(bins).enter().append('text').attr('class', 'bar-label').attr('x', {
                    "Histogram.useEffect": (d)=>x(`${d.x0} - ${d.x1}`) + x.bandwidth() / 2
                }["Histogram.useEffect"]).attr('y', {
                    "Histogram.useEffect": (d)=>y(d.length) - 5
                }["Histogram.useEffect"]) // 5px above bar top
                .attr('text-anchor', 'middle').style('fill', 'black').style('font-size', '10px').text({
                    "Histogram.useEffect": (d)=>d.length
                }["Histogram.useEffect"]);
                // X-axis
                svg.append('g').attr('transform', `translate(0,${height})`).call((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$axis$2f$src$2f$axis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["axisBottom"])(x));
            }
        }
    }["Histogram.useEffect"], [
        data
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        ref: svgRef
    }, void 0, false, {
        fileName: "[project]/src/components/histogram.js",
        lineNumber: 83,
        columnNumber: 10
    }, this);
};
_s(Histogram, "nqvpgDYhqZk6yiBjM3Bn8A1gQaM=");
_c = Histogram;
const __TURBOPACK__default__export__ = Histogram;
var _c;
__turbopack_context__.k.register(_c, "Histogram");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/horizontalBarChart.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/d3/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$group$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/group.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-selection/src/select.js [app-client] (ecmascript) <export default as select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-array/src/max.js [app-client] (ecmascript) <export default as max>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-client] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/band.js [app-client] (ecmascript) <export default as scaleBand>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const HorizontalBarChart = ({ variables })=>{
    _s();
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HorizontalBarChart.useEffect": ()=>{
            const fetchDataAndDraw = {
                "HorizontalBarChart.useEffect.fetchDataAndDraw": async ()=>{
                    const response = await fetch('http://localhost:5001/data');
                    const rawData = await response.json();
                    // Process data client-side
                    const processedData = variables.map({
                        "HorizontalBarChart.useEffect.fetchDataAndDraw.processedData": (varName)=>({
                                varName,
                                counts: Array.from((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$group$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rollup"])(rawData, {
                                    "HorizontalBarChart.useEffect.fetchDataAndDraw.processedData": (v)=>v.length
                                }["HorizontalBarChart.useEffect.fetchDataAndDraw.processedData"], {
                                    "HorizontalBarChart.useEffect.fetchDataAndDraw.processedData": (d)=>d[varName]
                                }["HorizontalBarChart.useEffect.fetchDataAndDraw.processedData"]), {
                                    "HorizontalBarChart.useEffect.fetchDataAndDraw.processedData": ([key, value])=>({
                                            category: key,
                                            count: value
                                        })
                                }["HorizontalBarChart.useEffect.fetchDataAndDraw.processedData"]).sort({
                                    "HorizontalBarChart.useEffect.fetchDataAndDraw.processedData": (a, b)=>b.count - a.count
                                }["HorizontalBarChart.useEffect.fetchDataAndDraw.processedData"])
                            })
                    }["HorizontalBarChart.useEffect.fetchDataAndDraw.processedData"]);
                    drawChart(processedData);
                }
            }["HorizontalBarChart.useEffect.fetchDataAndDraw"];
            fetchDataAndDraw();
        }
    }["HorizontalBarChart.useEffect"], [
        variables
    ]);
    const drawChart = (dataset)=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(ref.current).selectAll("*").remove();
        // Dimensions
        const width = 600, height = 600;
        const margin = {
            top: 30,
            right: 40,
            bottom: 120,
            left: 160
        };
        // Create SVG
        const svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(ref.current).append('svg').attr('width', width).attr('height', height);
        // Process data
        const maxCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(dataset.flatMap((d)=>d.counts.map((c)=>c.count))) || 1;
        // Scales
        const xScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
            0,
            maxCount
        ]).range([
            margin.left,
            width - margin.right
        ]);
        const yScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(dataset.map((d)=>d.varName)).range([
            height - margin.bottom,
            margin.top
        ]).padding(0.2);
        // Create variable groups
        const variableGroups = svg.selectAll('.variable-group').data(dataset).enter().append('g').attr('transform', (d)=>`translate(0,${yScale(d.varName)})`);
        // Add bars and labels
        variableGroups.each(function(d) {
            const categoryScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(d.counts.map((c)=>c.category)).range([
                0,
                yScale.bandwidth()
            ]).padding(0.05);
            const group = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$selection$2f$src$2f$select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__select$3e$__["select"])(this);
            // Bars
            group.selectAll('rect').data(d.counts).enter().append('rect').attr('x', margin.left).attr('y', (c)=>categoryScale(c.category)).attr('width', (c)=>xScale(c.count) - margin.left).attr('height', categoryScale.bandwidth() * 0.95).attr('fill', '#4f46e5').attr('rx', 4);
            // Count labels (top of bars)
            group.selectAll('.count-label').data(d.counts).enter().append('text').attr('class', 'count-label').attr('x', (c)=>xScale(c.count) + 28).attr('y', (c)=>categoryScale(c.category) + 11).attr('text-anchor', 'end').style('font-size', '0.7em').style('fill', 'black').text((c)=>c.count);
            // Category labels (right side)
            group.selectAll('.category-label').data(d.counts).enter().append('text').attr('class', 'category-label').attr('x', (c)=>xScale(c.count) - 5).attr('y', (c)=>categoryScale(c.category) + categoryScale.bandwidth() / 2).attr('dy', '0.35em').attr('text-anchor', 'end').style('font-size', '0.7em').style('fill', 'white').text((c)=>c.category);
        });
        // Variable labels (multi-line)
        variableGroups.append('text').attr('x', margin.left - 15).attr('y', yScale.bandwidth() / 2 - 10).attr('text-anchor', 'end').attr('dominant-baseline', 'middle').style('font-size', '0.85em').selectAll('tspan').data((d)=>d.varName.split('_')).enter().append('tspan').attr('x', margin.left - 15).attr('dy', (d, i)=>i === 0 ? 0 : '1.2em').text((d)=>d.charAt(0).toUpperCase() + d.slice(1).toLowerCase());
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref
    }, void 0, false, {
        fileName: "[project]/src/components/horizontalBarChart.js",
        lineNumber: 127,
        columnNumber: 10
    }, this);
};
_s(HorizontalBarChart, "8uVE59eA/r6b92xF80p7sH8rXLk=");
_c = HorizontalBarChart;
const __TURBOPACK__default__export__ = HorizontalBarChart;
var _c;
__turbopack_context__.k.register(_c, "HorizontalBarChart");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Home)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$histogram$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/histogram.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$horizontalBarChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/horizontalBarChart.js [app-client] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '../components'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
"use client";
;
;
;
;
function Home() {
    const BarchartVariables = [
        'Parental_Involvement',
        'Access_to_Resources',
        'Motivation_Level',
        'Family_Income',
        'Teacher_Quality',
        'Parental_Education_Level',
        'Distance_from_Home'
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                children: "Student Performance Histogram"
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 11,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$histogram$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 12,
                columnNumber: 6
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$horizontalBarChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variables: BarchartVariables
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 13,
                columnNumber: 6
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Gender, {}, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 14,
                columnNumber: 6
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
}
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_be31bec3._.js.map